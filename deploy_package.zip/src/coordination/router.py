from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from src.core.schemas.error import AUTH_ERRORS, COMMON_ERRORS
from src.domain_staff.auth import require_active
from src.infrastructure.database import get_db
from src.coordination.schemas import AttentionResponse, DailyDashboardResponse, SlaResponse
from src.coordination.services import get_attention, get_daily_dashboard, get_sla_report

router = APIRouter(prefix="/ops", tags=["ops"])

# ==========================================
# 日次ダッシュボード（全顧客横断）エンドポイント
# ==========================================

@router.get("/daily", response_model=DailyDashboardResponse, responses={**COMMON_ERRORS})
def get_daily_dashboard_endpoint(
    target_date: date | None = Query(None, alias="date", description="表示する日 (例: 2026-11-02)。省略時は timezone での今日"),
    timezone: str = Query("Asia/Tokyo", description="日付の振り分けに使うタイムゾーン"),
    db: Session = Depends(get_db),
):
    """
    指定日に予定されている全顧客の予定を、顧客 → 業務の順にまとめて返します。
    その日の年間計画シートの日付と、各営業日カレンダーでの休日かどうかも返します。
    過去の日付では、無効化・取消された予定も理由付きで返します。
    """
    return get_daily_dashboard(db=db, target_date=target_date, tz_name=timezone)


@router.get("/attention", response_model=AttentionResponse, responses={**COMMON_ERRORS})
def get_attention_endpoint(
    limit: int = Query(200, ge=1, le=1000, description="最大件数（締切の早い順）"),
    db: Session = Depends(get_db),
):
    """
    完了・取消以外で、締切を過ぎた（遅れ）か「まもなく」の時刻を過ぎたオーダーを、日付によらず締切の早い順に返します。
    日次ダッシュボードの上の「締切が近い・遅れ」の一覧用（数分おきに読まれる想定。保存した締切を部分インデックスで引く）。
    """
    return get_attention(db=db, limit=limit)


@router.get("/sla", response_model=SlaResponse, responses={**COMMON_ERRORS, **AUTH_ERRORS})
@require_active()
def get_sla_report_endpoint(
    from_month: str | None = Query(None, alias="from", description="最初の月 YYYY-MM（省略時は to の 11 か月前）"),
    to_month: str | None = Query(None, alias="to", description="最後の月 YYYY-MM（省略時は今月、日本時間）"),
    client_code: str | None = Query(None, description="顧客コードで絞り込む（省略時は全顧客）"),
    db: Session = Depends(get_db),
):
    """
    SLA の集計: 顧客 × 締切の月（日本時間）。完了・遅れ・期限内率・平均遅れ（遅れたものだけ）・未完了の遅れ。
    取消したオーダーは数えない。期間は最大 36 か月。有効な職員なら誰でも。
    """
    return get_sla_report(db=db, from_month=from_month, to_month=to_month, client_code=client_code)
