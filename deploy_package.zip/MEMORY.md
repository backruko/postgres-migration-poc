# MEMORY.md — Session handoff

Handoff for the next working session. Read this first, then the design doc (§2), `frontend/README.md` (frontend
details), `src/domain_plan/`, `src/coordination/`, `src/domain_ope/`, `src/domain_biz/` and `src/domain_staff/`
(backend). Last updated: 2026-11-05 (evening), after the SLA report.

## 1. Current status

- **Built and merged into `main`, and pushed by the user (`main` = `origin/main` = `706f166`, 2026-11-05):** all seven
  phases of the design doc (Plan MVP + 1 daily dashboard · 2 generation job · 3 staff · 4 ope orders · 5 steps /
  maker-checker · 6 dependencies · 7 client events / signals) plus the 2026-11-05 work below. Per-phase "as built"
  notes, decisions and step plans are in §2. **The user pushes; I never do.** The user sometimes commits a step
  themselves — check `git log` before committing. Working tree clean; no work in progress.
- **2026-11-05 (one long session), all merged with `--no-ff`, each step reviewed + committed on the user's "go":**
  | Work | Branch → merge | What (detail in §2) |
  |---|---|---|
  | UX shortcuts U.1–U.3 | `feature/ux-shortcuts` → `700350e` | calendar day double-click → dashboard; ⚙ row link → template (highlight); 「← 戻る」 links via router state; template / 業務の設定 edits = admin |
  | Test fixes | `fix/test-client-codes` → `e666056`, `fix/test-client-codes-all` → `7ead116` | time-independent sheet-link test; **`tests/client_codes.py` `new_client_code(prefix)`** in every test file |
  | Small debts D.1 / D.2 | `feature/small-debts` → `d6ad461` | staff names (`actor_name`) in timelines; SOP version pin / unpin in the drawer (`GET /biz/{id}/versions`) |
  | Admin guard U.4 | `feature/admin-guard` → `f3d483e` | every `/plans` + `/biz` write = admin, except calendar occurrence changes (変更 / 取消 / 臨時 / ルールに戻す / 取消の復元) = releaser or admin; operators only view calendar / settings |
  | Phase L "latest before due" | `feature/latest-before` → `cdd8960` | 3rd dependency rule 直前の上流 with `lookback_days` (migration `2f7614f1cb02`) |
  | Phase N deadlines | `feature/deadlines` → `1ba7cdb` | per-template deadline (予定の終了 / 開始から / 固定の時刻) + warning lead (default 0); **stored on the order** (`deadline_at`, `warn_at`, rule snapshot, `finished_at`), fixed at release; 遅れ / まもなく from stored columns; `GET /ops/attention`; 2-min auto-refresh (migrations `d17d631f5ad2`, `c5bb40015e61`, `51d8d829a2d2`) |
  | Dashboard tabs | `feature/dashboard-tabs` → `0c6d15e` | 日次ダッシュボード tabs 予定 / 締切・遅れ (n) / 信号 (n), `?tab=` |
  | Logging | `fix/log-rotation` → `4cbeab2`, `44e1687` (main), `fix/sql-echo-switch` → `fb0c827` | `app.log` rotates 10 MB × 5 (`LOG_FILE` / `LOG_MAX_MB` / `LOG_BACKUPS` env vars); rotated files git-ignored; **SQL logging off by default**, `SQL_ECHO=1` (in `.env` or env) turns it on |
  | SLA report | `feature/sla-report` → `706f166` | `GET /ops/sla` + nav 「SLA」 page `/reports/sla` (client × deadline month: 完了 / 遅れ / 期限内率 / 平均遅れ / 未完了の遅れ, CSV export) |
- **Next: the MVP roadmap (decided by the user 2026-11-05 evening).** Goal: a small MVP online on the **internal
  network, own team only**. Order: **M1 → M2 → login → deployment**; the pool below waits until after go-live.
  - **M1 client + business screens: done, merged into `main` (`44c1737`, 2026-11-06, not pushed)** — commits
    `2729ea7` M1.1 backend · `5a619b6` M1.2a 設定 menu · `2cfb5fa` M1.2b 顧客 page · `13a7238` M1.2c 業務 page (detail in
    §2 "M1").
  - **M2 SOP screens: done, merged into `main` (`28b94b6`, 2026-11-06, not pushed; user browser-tested OK)** —
    commits `5b054ea` M2.1 … `17aa788` M2.6 (detail in §2 "M2").
  - **Login** (branch `feature/login` from `main` `28b94b6`; plan approved 2026-11-06, see §2 "Login"):
    LG.1 `3a93ffd` (migration `b4e8d2a6c913`), LG.2 `c644b4d` (backend switch), LG.3 `311c38e` (frontend).
  - **Deployment files** `7a2e3c6` on `feature/deployment` (from `feature/login`); see §2 "Deployment".
  - **Login + deployment merged into `main` (`895cbe5`, 2026-11-06, not pushed).** Never run in Docker yet (no Docker
    on the office PC) — **waiting for the user's test report from the VM** before anything else.
  - **Deployment** (user's decisions 2026-11-05, doc rev 78): **Linux VM + Docker Compose**, services `db`
    (PostgreSQL 16, volume, daily `pg_dump`), `app` (uvicorn + production frontend build same-origin with SPA
    fallback), **`worker`** = a loop replacing Task Scheduler: release due orders, sleep until the next release
    moment capped at 60 s (≈1 min precision; overdue ones go out on the next pass), plus the daily plan extension at
    00:05 (later: notifications). Chosen over per-order JIT timers (too many invalidation paths, lost on restart) and
    over a 1-min OS cron. Worker built **in the deployment step** (order unchanged); the two local Task Scheduler
    entries stay until then. Production `.env` outside the image; then a go-live checklist (real master data,
    `create_orders.py`, browser checks).
- **Pool (after go-live)**, smallest first: (1) notifications (mail / Teams / Slack)
  for まもなく / 遅れ — needs the user's tool + webhook; (2) SFTP watcher "B" (§2 "Todo pool") — needs server access
  and file rules; (3) SOP version screen + "impact before approval" list (no SOP UI exists yet); (4) client-limited
  role (§2 "Planned"); (5) real login replacing `X-Staff-Id` (design doc first). Plan any of them like Phases 5–7:
  questions first (AskUserQuestion with a recommended option), a step plan the user approves, one step at a time,
  each left uncommitted until "go".
- **Browser check — done by the user, all fine (confirmed 2026-11-05, late session)** for the list below. Was: not yet clicked through (only U.1–U.3 were, OK): dashboard tabs + badges, the order
  drawer (staff names in 記録 / step lines, SOP 指定 / 解除, 締切 / 完了 lines, まもなく), the 締切 section of the template
  form + 締切 column, まもなく / 遅れ on rows, the 2-min auto-refresh, admin-only settings (sheets / holidays / templates /
  業務の設定) and the operator's read-only calendar, 直前の上流 in 業務の依存関係, the SLA page + CSV in Excel. Earlier
  screens from Phases 5–7 were never clicked through either. A "slow drawer spinner" report on 2026-11-05 could not be
  reproduced: server ~25 ms, Vite proxy ~25 ms — most likely the uvicorn console paused by a text selection
  (Windows QuickEdit); advised turning QuickEdit off.
- **DB:** latest Alembic head **`b4e8d2a6c913`** (LG.1, login tables; **the user must run `alembic upgrade head`** —
  their dev DB was at `7a3c5e9b1d24`, confirmed 2026-11-06). Chain: `ceee1634d6a7` (squashed init) → `34bdbd214739` →
  `9ee3f3e0624e` → `9b2ec314368a` → `3493c39bdf43` → `5c1f7d2a9e04` → `568c3287c359` (staff) → `f9bbe9648f15` (biz
  release settings) → `9e1bcef6cbc7` (ope tables) → `5eede5808433` → `971958268657` (step template condition /
  is_blocking) → `966b78ff950f` (ope_step, ope_step_event) → `6c8cc87274c8` (ope_step.retired_at) → `2904467fd7b9`
  (biz_dependency) → `cb0ae371f402` (ope_dependency) → `58425e70286d` (DEPENDENCY_OVERRIDE_APPROVED) → `6a7849dbf2ec`
  (biz client-event settings) → `3242f180527a` (ope_signal, role signal_sender) → `2f7614f1cb02` (latest_before +
  lookback_days, L.1) → `d17d631f5ad2` (plan_template deadline fields, N.1) → `c5bb40015e61` (ope_order deadline
  snapshot + deadline_at / warn_at / finished_at, N.2) → `51d8d829a2d2` (attention partial indexes, N.3) → `7a3c5e9b1d24` (SOP version states from dates, M2.1) → `b4e8d2a6c913` (staff login: passwords, sessions, API keys, LG.1).
  **The user's dev DB:** on 2026-11-05 at 16:39 their uvicorn (8000) was already reading the N.2 columns and serving
  `/ops/attention`, so it was upgraded at least to `c5bb40015e61`; **the user confirmed it is at head `51d8d829a2d2`
  (2026-11-05, late session)** — never
  run alembic against `dev_db` myself. The user runs `alembic upgrade head`; their uvicorn on 8000 auto-reloads, so a
  model change without the migration returns 500 until they upgrade. **Warn them whenever a step adds a migration.**
  Dev DB facts: staff 1 login `system` has system_admin + operator / checker / releaser but **not admin** (needs
  業務管理者 to edit settings since U.3 / U.4); 1 client MOCK; biz 13 / 14 in use; `app.log.1` (1.35 GB, pre-rotation)
  can be deleted by the user.
  **`plan_check`** (throwaway, mine) is at `b4e8d2a6c913`. Seeded: client `MOCK`, biz 1 `MOCK0001` (one approved SOP
  version `v9.26817.0`; SOP version 1 with 3 step templates), biz 2 `MOCK0002` (LIGHTWEIGHT + AUTOMATIC
  `data_received`, daily template 23), calendar `JP_BANK` id 1, the mock sheet. Staff: 1 `check-admin` (system_admin),
  2 suspended, 3 viewer+auditor, **4 operator, 5 releaser**, 6 / 7 checkers, **8 admin**, 9 / 10 signal_sender. 14
  open orders are past their deadline there (good for 遅れ / attention / SLA checks).
- **Tests:** `pytest tests/ --ignore=tests/client_biz_check.py --ignore=tests/client_biz_check2.py` → **175 passed**,
  ~2.5–6 min. Runs against `test_db` via `tests/conftest.py` (`create_all`, no migrations; the order-sync listener —
  and with it the biz dependency and template listeners — is registered there). **Every new test file uses
  `from tests.client_codes import new_client_code` with its own prefix letter**; used: T D B O S A R V P K M G L N Q E
  H J W F Y U C X Z (test_credentials / test_login use no client). Type check: `npx pyright@1.1.400 --pythonpath .venv/Scripts/python.exe src main.py tests scripts` → 0
  errors. Migration check (on `plan_check`): `alembic upgrade head` / `downgrade -1` / `upgrade head` / `alembic
  check` → no drift; run alembic with `export DATABASE_URL=$(grep ^DATABASE_URL .env | cut -d= -f2- | sed
  's#/dev_db$#/plan_check#')` (`.env` points at the user's `dev_db`). Frontend: `cd frontend && npm run build` passes.
  After backend schema changes: `python scripts/export_openapi.py` then `npm run gen:api`.
  **Harness pattern:** uvicorn on 8001 against `plan_check` **with `LOG_FILE=app-8001.log`**, then bundle the real
  frontend modules with esbuild (`--define:import.meta.env='{"VITE_API_BASE_URL":"http://127.0.0.1:8001",
  "VITE_TIMEZONE":"Asia/Tokyo"}'`) and run them in node; wait for `/plans/calendars` = 200 before calling.
- **Scheduled jobs (user's machine):** Task Scheduler `\postgres-migration-poc\PlanExtendJob` (daily 00:05,
  `scripts/extend_plans.py`) and `\postgres-migration-poc\OrderReleaseJob` (every 15 min, `scripts/release_orders.py`).
  Any new script that changes plan must call `order_sync.register()`.

### Commits by phase (newest first; full detail per step in §2)
| Phase | Commits |
|---|---|
| SLA report (`feature/sla-report`) | `16045c6` S.2 page + CSV · `aae5c50` S.1 endpoint |
| Dashboard tabs | `36ce2e9` |
| N deadlines (`feature/deadlines`) | `7ab2cc3` N.4 frontend · `95c94fe` N.3 re-stamp + read side + attention · `503f3c6` N.2 order columns · `2e5228f` N.1 template fields |
| L latest before due (`feature/latest-before`) | `e3541c3` L.3 · `c653251` L.2 · `bfaab32` L.1 |
| U.4 admin guard / D.1–D.2 small debts | `60ce2cb` U.4 · `f4e6dbf` D.2 · `9036c8f` D.1 |
| UX shortcuts U.1–U.3 | `34914a8` U.3 · `f002f9f` U.2 · `9b7cb38` U.1 |
| 7 client events / signals (`feature/ope-signals`) | `22fec2a` 7.5 screens · `a7e1e03` 7.4 late + signal list · `0b5e762` 7.3 receive / match · `a9f8fc3` 7.2 ope_signal + role · `0ff76dd` 7.1 biz settings · `c1aade1` plan |
| 6 dependencies (`feature/ope-dependencies`) | `3669528` 6.5 screens · `916ebee` 6.4 start check + override · `1a364ca` 6.3 link resolution · `3eaede4` 6.2 ope_dependency · `8ab5f92` 6.1 biz_dependency |
| 5 steps (`feature/ope-orders`) | `6a37fee` docs · `75cc109` 5.5 (user) · `074840f` 5.4 · `abe6281` 5.3 · `11cd510` docs · `fc58dd0` 5.2 · `05850c1` / `5dbbe0f` 5.1 (user) |
| 4 orders (`feature/ope-orders`) | `d151fbf` 4.7 · `4790ac1` 4.6 · `09f7455` 4.5 · `0389de2` 4.4 · `7d94be7` 4.3 · `0552e9f` 4.2 · `d65af44` 4.1 |
| 1–3 (merged `23767b8`) | `702ebbb` / `bfe3deb` staff · `fcff659` generation job · `eb4e6b5` / `17f9bcc` / `9306e23` dashboard |

## 2. Target architecture — "Operations Orchestration Design" (draft for team review)

Design doc (Claude Docs): https://claude.ai/artifact/W4XgfnPTH4iJPstx362xpV — the source of truth for this section.
Decided in the doc's comments (2026-10-28): SOP version + steps **freeze at release**.
Before building any phase, re-read the doc: the team may have edited or commented on it.
**Last rev written by me: 89 (2026-11-06, "MVP deployment" paragraph: what was built — HTTP intranet, nginx web, migrations at start, nightly backup)** — read with `{"kind": "view", "sinceRev": 89}` to see only newer edits, and
query comments with `afterSeq: 24`. Doc ids: project `eb57297f-757b-4c1e-9116-9e545b1abd76`, body node `9e7b6bb0-1c80`.
The delivery-phase list in the doc carries the build status (phases 1–7 plus 8 deadlines and 9 SLA report, built and merged; rev 77). Rev 77 also added: SLA report and dashboard tabs bullets, latest-before note under phase 6, ope_order deadline columns in the data model.

### Domains (decided: plan and ope stay separate, no merge)
| Domain | Owns | Status |
|---|---|---|
| **biz** | What the work is: businesses (release + client-event settings), SOP versions (`effective_at` / `expired_at`), step templates (condition, is_blocking), dependency definitions | Built (`src/domain_biz/`) |
| **plan** | When it is due: templates, sheets, holidays, occurrences. Recomputable; regenerated freely, future only; knows nothing about ope | Built (`src/domain_plan/`) |
| **ope** | What happened: orders, steps, append-only events, dependency links, signals. Facts, never recomputed | Built (`src/domain_ope/`: services, steps, links, signals) |
| **staff** | Who: users and roles (operator, checker, releaser, admin, viewer, auditor, system_admin, signal_sender) | Built (`src/domain_staff/`) |
| **Coordination layer** | Cross-domain glue in one DB transaction (plan → order sync, biz definition listener) + read models (daily dashboard) | Built (`src/coordination/`) |

Dependency direction: ope → plan (reads slots), ope → biz (pins SOP version), ope → staff (actor), plan → biz
(template's business). plan never imports ope.

### Occurrence ≠ order
- Occurrence (plan) = "by the rule, this work is due in this slot". Order (ope) = "we do this work under this SOP version".
- **One order per slot `(template_id, occurrence_date)`**; plan voids and recreates instances, the order survives.
- **Eager creation:** every generated occurrence gets a `pending` order immediately; pending/ready orders follow plan changes.

### Visibility beyond 90 days (built in Phase 2)
- Per-template high-water mark `materialized_until`; reads still extend it on demand (`_materialize_templates`, cap
  now + 2 years, `MAX_LOOKAHEAD`).
- `_ensure_next_occurrence` extends to max(now + 90 days rounded up to the next UTC midnight, the **next occurrence**),
  cap 2 years; skips manually cancelled slots and keeps looking. Runs on template create / restore, at the end of every
  `_regenerate` (edits, explicit dates, holiday / sheet cascades) and in the daily job `extend_all_templates`
  (`scripts/extend_plans.py`, commits per template, idempotent within a day).
- Templates with nothing upcoming within 2 years: `next_occurrence_at = null` → warning on the settings page.
- Phase 4 still to do: orders created for the same set.
- Known edge (pre-existing): a template whose mark is in the past gets the gap filled from the old mark (past dates
  included) on its next extension. The daily job prevents new gaps.

### Order lifecycle
- Statuses: `pending → ready → in_progress → finished`; `on_hold` (保留, no date; resume returns to the previous status);
  `canceled`. `finished` / `canceled` are final.
- **Who may do what (decided 2026-10-28):** **releaser and admin** release, pin a version, force-start and resolve
  conflicts → `@require_roles(["releaser", "admin"])`.
- **Release** (pending → ready), per business `release_mode`: `MANUAL_APPROVAL` (releaser or admin) or `AUTOMATIC`
  (at `release_lead`; **default 03:00 JST on the scheduled day**, decided 2026-10-28: after the nightly batch
  (夜間バッチ), which often runs until about 02:30). Release freezes SOP version + steps.
- **Start** (ready → in_progress): operator, **on or after the scheduled day (JST) only** (decided 2026-10-28);
  earlier needs a **releaser's approval** (an order event). Hard dependencies must be met, or a releaser / admin
  force-starts with reason.
- **Reschedule** (延期) is not a status: it is a plan reschedule; the order follows while pending / ready / on hold.
  A person cannot reschedule an order in progress.
- Cancel: a person with reason; the system only when a pending/ready order's slot disappears.
- Every transition = an order event (who or `system`, when, why).

### SOP version resolution
- `resolved = pinned ?? version effective on the scheduled date` (biz `effective_at` ≤ date < `expired_at`).
- The SOP approval screen shows the impact list ("upcoming orders that will run v4").
- A releaser or admin can pin a pending order to any approved version, and unpin; recorded as events.
- Frozen at release (decided).

### Steps
- Built at release from the frozen version; step template `condition`: `always` | `month_in` | `first_in_week`
  (read from plan's occurrences); live preview while pending.
- States `locked → todo → submitted (operator) → approved (checker)`; reject (reason required) → `todo`.
- Next step unlocks on **submit**; if the step's `is_blocking` (on the step template, versioned) → on **approve**.
- Rejecting a non-blocking step does not reset later steps; the order finishes when all steps are approved.
- Four-eyes: checker ≠ operator (needs staff).

### Dependencies (recommended: hard by default)
- Hard blocking + audited human force-start (with reason); `informational` links never block. Reason: an automated
  executor needs a yes/no precondition, and links that start hard are already correct for automation.
- Checked at ready → in_progress, not at release.
- Matching: same `source_sheet_event_id` (both offset from the same baseline date, e.g. 受領 and 本処理 from one 振込日),
  same `occurrence_date`, or "latest upstream before due" (to confirm).
- Upstream canceled or on hold → downstream stays blocked; a person decides (force-start or cancel).
- Definitions in biz (`biz_dependency`, cycle-checked on save); concrete links in ope.

### Plan changes → orders (coordination layer)
| Plan change | Pending / ready | On hold | In progress | Finished / canceled |
|---|---|---|---|---|
| A person reschedules / cancels | Follows / canceled | Follows / canceled | **Refused** | Not affected |
| The system moves the slot (holiday, revision, sheet date) | Follows (flag if step conditions change) | Follows | Stays + conflict flag | Not affected |
| The slot disappears | Canceled by system | Conflict flag | Conflict flag | Not affected |
| New slot | New pending order | — | — | — |

Mechanism (decided 2026-10-28): **slot-change listener** — plan's reconcile / manual changes hand a per-slot change set
to listeners registered at startup; the coordination layer's listener applies it to orders in the same transaction.
Plan never imports ope.

### Client-side events
- A business with `execution_type = LIGHTWEIGHT` → an order with zero steps, same lifecycle.
- `completion_mode`: `MANUAL` (operator marks received) or `AUTOMATIC` via `POST /ope/signals {type, client_code, key,
  received_at}` (append-only; unmatched signals shown, never dropped); manual way out with reason. "Late" is computed.

### Data model sketch (from the doc)
- biz: `biz_master` + `execution_type`, `release_mode`, `release_lead`, `completion_mode`, `signal_type`;
  `sop_step_template` + `condition` (JSON), `is_blocking`; new `biz_dependency`.
- staff: `staff_user`, `role`, `staff_role`.
- ope: `ope_order` (unique slot, current instance, status cache, pinned / frozen SOP version, `released_at`, `conflict`),
  `ope_order_event`, `ope_step`, `ope_step_event` (all events append-only), `ope_dependency`, `ope_signal`.
- plan: tables unchanged; + the daily generation job; reconcile returns a per-slot change set.

### Delivery phases
1. ~~Cross-client daily dashboard~~ **done** (§4 Coordination, §5 `/daily`).
2. ~~Plan generation job + next-occurrence guarantee + "no upcoming occurrence" warning~~ **done** (user chose: CLI
   script + OS scheduler; warning from a template field).
3. ~~staff (users, roles)~~ **done** (§4 Staff, §5 職員). User decisions: no login yet (trusted `X-Staff-Id` header);
   fixed global roles; backend first, screen second.
4. ope orders: eager creation, propagation, statuses, release modes, SOP resolution / pinning, conflict flags. ← **next**
   (branch `feature/ope-orders`). Decided 2026-10-28: slot-change listener; orders only for live occurrences from
   go-live on (no past backfill); interim finish = operator marks in_progress → finished (Phase 5 replaces it for
   orders with steps); release config on biz_master = `release_mode`, `release_time` (default 03:00 JST),
   `release_days_before` (default 0).

#### Phase 4 step plan (approved by the user 2026-10-28; one step at a time, each reviewed + committed)
| # | Step | Migration | Status |
|---|---|---|---|
| 4.1 | Release settings on `biz_master` + biz API | `f9bbe9648f15` | **done** (`d65af44`) |
| 4.2 | ope tables: `ope_order`, append-only `ope_order_event` (immutability trigger like plan's `plan_reject_mutation`). Models + migration + tests, **no behavior** | `9e1bcef6cbc7` | **done** (`0552e9f`) |
| 4.3 | **done** (`7d94be7`) — Slot-change listener in plan (reconcile + manual override / cancel / revert / one-off / restore emit per-slot changes) + coordination listener (create / move / cancel / conflict-flag orders per the propagation table) + script creating orders for existing future live occurrences | — | |
| 4.4 | **done** (`0389de2`) — Status API: release (releaser/admin), start (operator, on/after the scheduled day JST, earlier only with a releaser's approval event), hold / resume, cancel (reason), finish (operator, interim), resolve conflict (releaser/admin); every transition an order event; `@require_roles` | — | |
| 4.5 | **done** (`09f7455`) — Automatic release job (03:00 JST; `release_time` / `release_days_before`) + its own Task Scheduler entry (registered by the user) | — | |
| 4.6 | **done** (`4790ac1`) — SOP version resolution, pin / unpin (releaser/admin), freeze at release | none needed | |
| 4.7 | **done** (`d151fbf`) — Frontend: order status on the dashboard + actions | — | |

**4.2 as built (`src/domain_ope/models.py`, migration `9e1bcef6cbc7`) — order slot identity = plan's slot.**
Plan has three slot kinds: rule-generated `("date", occurrence_date)`, sheet-based `("sheet_event",
source_sheet_event_id)` (survives a sheet date move), and **one-offs, which have no slot in plan** (`add_one_off` sets
only its own date; overrides inherit their original's slot). User's decision 2026-10-30: **typed slot columns** —
`ope_order` keeps `template_id` + `occurrence_date` always, plus `source_sheet_event_id` (snapshot, no FK, like plan)
**or** `one_off_instance_id` (FK plan_instance: the one-off's *first* instance; later moves keep it).
Partial unique indexes `uq_ope_order_sheet_slot`, `uq_ope_order_one_off_slot`, `uq_ope_order_date_slot` (neither set) +
CHECK `ck_ope_order_one_slot_kind`. So 4.3's listener must find a one-off's root instance (walk
`overrides_instance_id`) to locate its order.
Other `ope_order` columns: `current_instance_id` (FK, last one after the slot disappears), `biz_master_id`,
`client_code` (FK client_master; for the future client-limited role), `scheduled_start` / `scheduled_end`, `status`
(`OrderStatus`, member names stored, default PENDING; cache of the latest event), `status_before_hold` (only while
ON_HOLD; PENDING / READY / IN_PROGRESS), `pinned_sop_version_id` / `frozen_sop_version_id` (FK sop_version),
`released_at` (required for READY / IN_PROGRESS / FINISHED), `conflict` + `conflict_reason` (required when conflict).
`ope_order_event` (append-only; trigger `trg_ope_order_event_immutable` → `ope_reject_mutation()`, also installed by
`create_all` for tests): `event_type` (`OrderEventType`: CREATED, STATUS_CHANGED, RESCHEDULED, PINNED, UNPINNED,
EARLY_START_APPROVED, CONFLICT_RAISED, CONFLICT_RESOLVED), `from_status` / `to_status`, `source` (HUMAN | SYSTEM;
CHECK: HUMAN ⇔ `actor_staff_id` set), `reason`, `detail` (JSONB), `occurred_at`. FK order_id RESTRICT (orders with
events can't be deleted). Adding an event type later = `ALTER TYPE … ADD VALUE` migration.
Tests: `tests/test_ope.py` (6, constraints only — they switch the 4.3 listener off with
`monkeypatch.setattr(slot_events, "_listeners", [])`; client prefix `"O"`). The doc's data-model rows were updated (rev 33).

**4.3 as built — plan → order sync** (decisions 2026-10-30: a returning slot gets a **new** order, the canceled one
stays as history → migration `5eede5808433` adds `status <> 'CANCELED'` to the three slot unique indexes; plan's
manual endpoints **require X-Staff-Id**).
- `src/domain_plan/slot_events.py` (plan side, knows nothing of ope): `SlotKey(template_id, kind date|sheet_event|
  one_off, ref, occurrence_date[compare=False])`, `slot_key_of(db, instance)` (one-offs: walk to the root),
  `live_instance_for_slot`, `record_created` / `record_voided` (called from the repo chokepoints `add_many`,
  `add_override`, `add_one_off`, `void_many`), `mark_person_change(db, actor_staff_id, note)` (called by the 5 manual
  services), `register_slot_listener`. A global `Session` `before_commit` hook groups the recorded slots and calls the
  listeners **in the same transaction**; `after_rollback` discards them. A listener exception aborts the commit.
- Plan manual services (`override_instance`, `cancel_instance`, `revert_instance`, `add_one_off_instance`,
  `restore_cancelled_instance`) take `actor_staff_id: int | None = None`; their endpoints have `@require_active()` +
  `current_staff` (→ the calendar's 変更 / 取消 / 臨時 / 元に戻す buttons get 401 until an acting staff is picked in
  the nav). Service calls without an actor (scripts, old tests) are recorded as SYSTEM events with
  `detail.cause = "manual plan change"`.
- `src/coordination/order_sync.py`: `register()` (called in `main.py`, `tests/conftest.py`, `scripts/extend_plans.py`,
  `scripts/create_orders.py` — **any new script that changes plan must call it too**), `apply_slot_changes` = the
  doc's propagation table: no order + live future instance → CREATED pending; moved → pending / ready / on_hold
  follow (RESCHEDULED, detail before / after), in_progress: person → `DuplicatedRecordError` code
  `ORDER_IN_PROGRESS` (409, rolls back the plan change), system → CONFLICT_RAISED + `conflict_reason`; removed →
  person: cancel (in_progress refused), system: pending / ready canceled with the plan void reason as `reason`,
  on_hold / in_progress conflict; finished untouched. No orders for past instances. `create_missing_orders(db)` =
  go-live backfill (`scripts/create_orders.py`, idempotent).
- Repo `src/infrastructure/repositories/Ope.py` (`ope_order_repo.get_active_for_slot` with `FOR UPDATE`,
  `add_event`, `get_events`).
- "Ready order whose step conditions change gets a flag" (doc table) waits for Phase 5 (steps).
- Tests: `tests/test_order_sync.py` (9; client prefix `"S"`). Doc rev 34 records both decisions.

**4.4 as built — order status API** (`src/domain_ope/{schemas,services,router}.py`, prefix `/ope`; no migration).
User decisions 2026-10-30: **cancel = releaser / admin** (reason required); **hold / resume = operator, releaser,
admin** (reason required to hold); start + finish = operator; release + resolve conflict = releaser / admin;
approve early start = **releaser only**; a releaser / admin **may release an AUTOMATIC business's order by hand**;
**a conflict flag blocks release and start** until resolved.
- `GET /ope/orders/{id}` (active staff) → `OrderDetailResponse` (order + `early_start_approved` + events oldest first).
- `POST /ope/orders/{id}/release | approve-early-start | start | hold | resume | finish | cancel | resolve-conflict`;
  every action locks the order (`ope_order_repo.get_locked`, FOR UPDATE), checks the status, appends one event
  (HUMAN, actor) and returns the detail. Wrong status → 400 (message lists allowed statuses).
- Start: scheduled day = `scheduled_start` in JST vs `_local_today()` (JST); before it only if an
  EARLY_START_APPROVED event exists (start event then has `detail.early_start = true`). Approving twice → 409;
  approving on/after the day → 400.
- Hold stores `status_before_hold`; resume returns to it. Finish = interim (Phase 5 replaces it for orders with steps).
- **Cancel also cancels the plan occurrence**: the order is marked canceled first, then
  `plan_services.cancel_instance(..., actor_staff_id)` voids the live instance (MANUAL, reason as note), so the
  listener finds no active order and creates nothing; the calendar drops it. Cancel works from in_progress too
  (unlike a plan-side cancel, which the listener refuses for in-progress orders).
- Resolve conflict: `accept_plan` (adopt the slot's live instance times; if the slot is gone → cancel), `keep` (clear
  the flag only), `cancel` (reason required; also cancels the plan occurrence if still live). One CONFLICT_RESOLVED
  event (with from / to status when it cancels).
- Force-start is **not** built (it belongs to dependencies, Phase 6). SOP freeze at release is 4.6.
- Tests: `tests/test_order_actions.py` (7; client prefix `"A"`; `monkeypatch.setattr(ope, "_now", …)` to pick
  "today"). HTTP-checked on `plan_check` with staff 4 (operator) and 5 (releaser). Doc rev 38 records the decisions.

**4.5 as built — automatic release** (no migration). `ope.release_due_orders(db) -> AutoReleaseResult{checked,
released}`: pending, non-conflicted orders of `AUTOMATIC` businesses (`ope_order_repo.get_pending_automatic`, FOR UPDATE
SKIP LOCKED, scheduled within 31 days) whose `release_moment` = (scheduled day JST − `release_days_before`) at
`release_time` JST has passed → ready, SYSTEM event `detail {"cause": "automatic release", "release_at": …}`.
Overdue ones (job was down) are released on the next run; idempotent. Manual and automatic release share
`_release()` (4.6 adds the SOP freeze there). Script `scripts/release_orders.py` (no listener needed: it doesn't touch
plan). **Runs every 15 minutes** (my call: release times differ per business, e.g. 21:30 the day before, so a single
03:00 run isn't enough; releases happen up to 15 min after the set time). Tests `tests/test_release_job.py` (3;
client prefix `"R"`). On `plan_check`: run with biz 1 manual → 0 checked; automatic → 71 checked, 0 released
(earliest pending is 11/1, due 11/1 03:00); set back to manual.

**4.6 as built — SOP version on orders** (no migration; the columns came with 4.2). User decision 2026-10-30:
**release goes ahead when no approved version is effective** (frozen = null; the release event detail says
`{"sop_version": null, "sop_note": "no SOP version effective on <day>"}`) — none of the user's businesses had an
approved SOP version on 2026-10-30.
- `ope.resolve_sop_version(db, order)` = pinned ?? `sop_version_repo.get_effective_at(biz, at=order.scheduled_start)`
  (non-draft, `effective_at ≤ at < expired_at`, newest `version_number`). Computed, so a plan move of a pending order
  changes it automatically. Biz's own `get_current_active_version` only works for "now" — don't use it for orders.
- `_release` freezes: `frozen_sop_version_id` + event detail `sop_version {id, version_tag, source pinned|effective}`.
  Manual and automatic release both go through it. A released order's version never changes (a later plan move
  keeps it).
- `POST /ope/orders/{id}/pin {sop_version_id, reason?}` / `…/unpin` (releaser, admin; pending only): same business,
  non-draft (older or newer); PINNED / UNPINNED events with `version_tag` / `previous_pin`.
- `OrderResponse.sop_version` = `{id, version_tag, source: frozen | pinned | effective}` or null.
- Not built from the doc's SOP section: the "impact before approval" list on the biz SOP approval screen
  ("which upcoming orders will run v4") — no step owns it yet; copying the step list at release is Phase 5.
- Biz quirk seen: only one FUTURE version may exist and nothing turns FUTURE into ACTIVE (status stays FUTURE;
  `dynamic_status` computes it), so tests create consecutive versions directly via the ORM.
- Tests: `tests/test_sop_resolution.py` (5; client prefix `"V"`). HTTP-checked on `plan_check` (biz 1 now has an
  approved version `v9.…` effective 2026-11-02, and order 191 is released with it frozen). Doc rev 39.
- The user's dev DB: biz 1 has SOP version id 1 `v1.1.0` (effective 2026-10-30 11:49; biz shows status "future") →
  biz 1's pending orders (e.g. 888–890) resolve to it.

**4.7 as built — order screen** (no migration). Backend: `/ops/daily` rows carry `order: {id, status, conflict,
conflict_reason}` (`ope_order_repo.get_active_by_instances`, one query; null for occurrences without an order).
Frontend: `domain/ope/{types,api,hooks,lib}` (`orderApi` = every `/ope/orders` action; `lib/orderActions.ts` = status /
event labels and `availableActions(order, staff, today, day)` mirroring the backend roles + rules, display only);
the 日次ダッシュボード rows show an order status tag (未リリース / リリース済 / 作業中 / 保留中 / 完了 / 取消) + 矛盾,
and clicking a row opens `OrderDrawer` (status, schedule, SOP version + source, release time, the actions the acting
staff may use with a reason / memo modal — reason required for hold, cancel, resolve-conflict cancel — and the event
timeline, newest first; actors shown as 職員 #id). **Not in the UI:** pin / unpin (biz has no endpoint listing a
business's SOP versions to pick from; API only), staff names in the timeline, the SOP "impact before approval" list.
Harness-checked through Vite on `plan_check` (10 checks). Frontend types regenerated (includes 4.3–4.6 changes).
5. Steps: conditions, maker-checker, `is_blocking`. **built** (5.1–5.5, branch `feature/ope-orders`)

#### Phase 5 decisions (2026-10-30, doc rev 41)
Rejecting a non-blocking step returns **only that step** to todo (later steps keep their state; the order can't
finish until all are approved). Steps are created at release but stay **locked until the order starts**; starting
opens step 1. **Only the checker role** approves / rejects, never the step's submitter (four-eyes). Already in the
doc: conditions `always` / `month_in` / `first_in_week` evaluated on the scheduled date (`first_in_week` = the
template's first occurrence in that ISO week, read from plan); live preview while pending, frozen at release; next
step opens on submit, or on approve when `is_blocking` (versioned on the step template); order finishes automatically
when the last step is approved; a ready order whose step conditions change after a system move gets a conflict flag.

#### Phase 5 step plan (approved 2026-10-30)
| # | Step | Status |
|---|---|---|
| 5.1 | biz `sop_step_template.condition` (JSONB, default `{"type": "always"}`) + `is_blocking` (default false); migration `971958268657`; schemas `StepCondition` = discriminated union `AlwaysCondition` / `MonthInCondition(months 1–12, deduped + sorted)` / `FirstInWeekCondition`; `clone_active_to_draft` copies both; tests in `tests/test_biz.py` | **done** (`05850c1`, pushed by the user) |
| 5.2 | ope tables `ope_step` (order_id, step_template_id, step_num, snapshot title / content / is_blocking, state) + append-only `ope_step_event`; migration `966b78ff950f` | **done** (`fc58dd0`, not pushed) |
| 5.3 | Build steps: live preview while pending (in the order detail), create + freeze at release, conflict flag when a system move changes a ready order's step set; migration `6c8cc87274c8` | **done** (`abe6281`, not pushed) |
| 5.4 | Step actions: submit (operator) / approve / reject (checker, four-eyes, reason for reject), unlock rules, start opens step 1, auto-finish on the last approval; manual finish only for zero-step orders | **done** (`074840f`, not pushed) |
| 5.5 | Frontend: steps + actions in the order drawer, step progress ("3/5") on dashboard rows | **done** (`75cc109`, committed + pushed by the user) |

**5.2 as built** (`src/domain_ope/models.py`, migration `966b78ff950f`). User decisions 2026-11-04 (all four as I
recommended): **events shaped like order events** (`StepEventType` CREATED | STATE_CHANGED, from / to required for a
change; reject = SUBMITTED → TODO, CHECK `ck_ope_step_event_reject_reason` requires `reason`); **actors only in the
events** (no submitted_by / approved_by on `ope_step`; 5.4's four-eyes check reads the latest → SUBMITTED event);
**non-matching steps get no row** (5.3 lists the skipped step templates in the release event detail); **`step_num` =
the template's number** (gaps allowed).
- `ope_step`: `order_id` (FK RESTRICT), `step_template_id` (FK sop_step_template RESTRICT — so an SOP version /
  step template used by an order can't be hard-deleted), `step_num` (> 0), snapshot `title` / `content` /
  `is_blocking`, `state` (`StepState` LOCKED default | TODO | SUBMITTED | APPROVED; cache of the latest event),
  timestamps. Unique `uq_ope_step_order_num`, `uq_ope_step_order_template`. The snapshot matters: biz's
  `cancel_future_version` turns a FUTURE version (pinnable) back into an editable DRAFT.
- `ope_step_event`: `step_id` (FK RESTRICT), `event_type`, `from_state` / `to_state`, `source` (reuses
  `ope_event_source_enum`, `create_type=False` in the migration), `actor_staff_id` (CHECK HUMAN ⇔ actor), `reason`,
  `detail`, `occurred_at`; trigger `trg_ope_step_event_immutable` → existing `ope_reject_mutation()` (models.py also
  re-creates the function for `create_all`, since table order isn't fixed). Downgrade drops the two new enum types.
- Tests `tests/test_ope_step.py` (4; client prefix `"P"`; listener switched off like `test_ope.py`).
- Doc rows for `ope_step` / `ope_step_event` updated (rev 48, after the user allowed the doc edit).

**5.3 as built** (`src/domain_ope/steps.py`, migration `6c8cc87274c8`). User decisions 2026-11-04 (all as I
recommended): **accept_plan rebuilds** the steps of a released, unstarted order whose step set changed (old rows get
`retired_at` + a RETIRED step event; the unique indexes ignore retired rows); **same-week orders are re-checked**
(first_in_week); **person moves flag too** (one rule for all plan changes). Doc rev 49 (paragraph after the
first_in_week note in Steps).
- Conditions on the scheduled day (JST): `month_in` = its month; `first_in_week` = no other live occurrence of the
  template (one-offs included) starts earlier in that ISO week (Mon–Sun JST), via new
  `plan_cache_repo.starts_for_template`. Same start time counts as first.
- `plan_steps(db, order, version) -> StepPlan(included, skipped)`; `create_steps` at release (in `_release`, so manual
  and automatic): LOCKED rows + CREATED step events with the release's source / actor; release event
  `detail.steps = {created: [nums], skipped: [{step_num, step_template_id, condition}]}` (no version → both empty).
- `GET /ope/orders/{id}` → `steps` (`OrderStepResponse`: id / state null in a preview) + `steps_preview` (true while
  not released; canceled unreleased → empty). Frontend types regenerated (no UI yet — 5.5).
- `order_sync.apply_slot_changes`: `_apply` returns the days touched (old + new scheduled day); afterwards
  `_recheck_steps` flushes, then for each template checks `ope_order_repo.get_released_unstarted` (ready, or on_hold
  from ready; FOR UPDATE) in the touched weeks → `step_set_change` → CONFLICT_RAISED, reason
  `ステップの条件が変わりました（追加: 2、除外: 3）`, detail `{cause: "step conditions changed", added, removed}`. Not raised
  twice; appended to an existing conflict reason with ` / `. `_raise_conflict` lost its unused `change` param.
- `resolve_conflict(accept_plan)`: after adopting the plan times, if `is_unstarted_release` and the set differs →
  `rebuild_steps` (retires **all** active rows, recreates from the frozen version; `detail.steps = {added, removed,
  created, skipped}`). keep = frozen steps stay. Started orders (in_progress / on_hold from in_progress) are never
  rechecked or rebuilt.
- Migration gotchas: autogenerate misses partial-index WHERE changes and enum values; `ALTER TYPE … ADD VALUE` works
  in the migration transaction (PG 16); the downgrade recreates the enum type and must drop / recreate the CHECKs
  that compare `event_type` with literals.
- Tests `tests/test_order_steps.py` (6; client prefix `"K"`; dates computed from today: `base_tuesday()` ≥ 14 days
  ahead, `next_month_tuesday`); release-detail assertions in `test_release_job.py` / `test_sop_resolution.py` now
  include `steps`. HTTP-checked on `plan_check` (uvicorn 8001): biz 1's version 1 got 3 step templates via SQL
  (always / month_in [12] / first_in_week blocking); order 18 (11/17) previewed [1, 3], released, moved by staff 4 to
  12/08 → conflict 「追加: 2」, start → 400, accept_plan → steps [1, 2, 3].

**5.4 as built** (no migration). User decisions 2026-11-04 (both as I recommended): **a conflict doesn't stop step
work, but the order can't finish while it's open** (the last approval leaves it in_progress; `resolve_conflict` accept_plan /
keep then finishes it); **steps are frozen while the order is on hold** (step actions only while in_progress).
My calls (doc rev 50): opening a step and the automatic finish are SYSTEM events (`detail.cause`: "order started" /
"previous step submitted" / "previous step approved" + `after_step`; order: "all steps approved"); four-eyes =
approver / rejecter ≠ the **latest** submitter of that step (`ope_step_repo.latest_submitter`), else 403 `FOUR_EYES`
(new `ErrorCode`); a resubmission by someone else lets the first submitter approve.
- `POST /ope/steps/{step_id}/submit` (operator, `OrderCommentIn`) · `/approve` (checker, comment) · `/reject` (checker,
  `OrderReasonIn`, reason required) → `OrderDetailResponse`. Each locks the **order** row first (`_get_step_for_action`,
  then `db.refresh(step)`), requires order in_progress and the step state (todo / submitted), else 400.
- Unlock (`steps.open_next_step`): only the immediate next active step, only if still LOCKED; non-blocking → on
  submit, `is_blocking` → on approve. Reject → that step back to todo, nothing else changes.
- `start_order` → `steps.open_first_step`. `finish_order` → 400 when the order has active steps (manual finish = zero
  steps only). `_finish_if_complete` after approve and after a non-cancel `resolve_conflict`.
- `OrderStepResponse.events` (`StepEventResponse`, oldest first; empty in a preview) — one query for all steps.
- Tests `tests/test_step_actions.py` (7; client prefix `"M"`; `monkeypatch.setattr(ope, "_now", …)` to start).
  HTTP-checked on `plan_check` (8001): new active checkers 6, 7; order 18 (12/08, steps 1, 2, 3 blocking) early-start
  approved by 5, started by 4 → step 1 todo; manual finish 400; operator approve / checker submit 403; empty reject
  reason 422; reject → resubmit; all approved → finished (SYSTEM "all steps approved"). Four-eyes over HTTP not checked
  (no plan_check staff is operator + checker); covered by the unit test.
- Frontend gap closed by 5.5 (完了 only for zero-step orders, steps in the drawer).

**5.5 as built** (no migration; no user decisions needed — my UI calls, listed here).
- Backend: `/ops/daily` `DailyOrderSummary.steps_total` / `steps_approved` (`ope_step_repo.progress_by_orders`, one
  grouped query, retired steps excluded); `OrderDetailResponse.steps` / `steps_preview` and
  `OrderStepResponse.events` are now **required** in the schema (openapi-typescript made `default_factory` fields
  optional). Test `test_dashboard_rows_carry_the_step_progress` in `tests/test_step_actions.py`.
- Frontend: `domain/ope/types` (StepState, StepEventType, OrderStep, StepEvent); `orderApi.submitStep / approveStep /
  rejectStep`; new `domain/ope/lib/stepActions.ts` (labels 待機 / 未提出 / 確認待ち / 承認済 — not 作業中, which is
  the order's; `describeStepEvent`, `latestSubmitter`, `rejectionReason`, `availableStepActions` mirroring the
  backend: in_progress only, submit = operator on todo, approve / reject = checker on submitted and not the latest
  submitter; `stepBlockedReason` explains the four-eyes case; `stepProgress`). `availableActions` offers 完了 only
  when `order.steps` is empty.
- `OrderDrawer`: section 「ステップ」 (承認 x/y; preview note before release) with `StepRow` per step (number, title,
  state tag, 承認で次へ tag for blocking, content pre-wrap, 差し戻し alert with the reason, last human action line,
  small 提出 / 承認 / 差し戻し buttons); the existing modal handles step actions too (`PendingAction` union; reason
  required for 差し戻し). Dashboard rows show `x/y` (mono, muted) after the title when the order has steps.
  CSS `.order-steps`, `.order-step*`, `.order-progress` (uses `--rule` / `--sheet`; there is no `--border`).
- Checked: `npm run build`; esbuild harness of the real modules (orderApi, stepActions, orderActions, dashboardApi,
  staffApi, actingStaff) in node **directly against uvicorn 8001** (`VITE_API_BASE_URL=http://127.0.0.1:8001`; the
  Vite proxy only strips `/api`, so Vite isn't needed for API checks) on `plan_check`: orders 74 (1 step) and 104
  (12/07, 3 steps incl. blocking) — preview, release, start, operator / checker actions, four-eyes hiding, reject
  reason, finish, dashboard "3/3": all 14 checks passed. **Not checked: the browser** (layout, the drawer, buttons) —
  the user clicks through.
6. Dependencies (hard + override, informational). **built** (6.1–6.5, branch `feature/ope-dependencies`)

#### Phase 6 decisions (2026-11-04, doc rev 54)
Matching rules built: **same sheet event** and **same occurrence date** ("latest before due" stays an open question;
add later as a new `match_rule` value). **A hard link whose upstream order can't be found = not met** (start refused;
releaser / admin force-start with reason). **Same client only** (doc open question ticked). Concrete links stored in
ope (`ope_dependency`), as the doc says. My call: definition writes need **admin** (業務管理者 = 業務の設定); reads open
like the rest of biz.

#### Phase 6 step plan (approved 2026-11-04)
| # | Step | Status |
|---|---|---|
| 6.1 | biz `biz_dependency` (upstream biz, downstream biz, match_rule, kind HARD / INFORMATIONAL) + API, cycle check on save; migration `2904467fd7b9` | **done** (`8ab5f92`, not pushed) |
| 6.2 | ope tables `ope_dependency` (upstream order, downstream order, definition, kind) — tables only; migration `cb0ae371f402` | **done** (`3eaede4`, not pushed) |
| 6.3 | Link resolution: create / refresh concrete links when orders are created or moved (order_sync) and when a definition is added or removed | **done** (`1a364ca`, not pushed) |
| 6.4 | Start check: hard links need the upstream order finished, else start → 400 listing blockers; force-start (releaser / admin, reason) as an order event; upstream canceled / on hold stays blocked; migration `58425e70286d` | **done** (`916ebee`, not pushed) |
| 6.5 | Frontend: dependency settings for a business, upstream / downstream in the order drawer, "blocked" tag + force-start | **done** (`3669528`, not pushed) |

**6.1 as built** (`src/domain_biz/models.py` end, migration `2904467fd7b9`). `BizDependency`: `upstream_biz_id` /
`downstream_biz_id` (FK biz_master RESTRICT), `match_rule` (`DependencyMatchRule` SAME_SHEET_EVENT |
SAME_OCCURRENCE_DATE), `kind` (`DependencyKind` HARD default | INFORMATIONAL), `created_at`; CHECK
`ck_biz_dependency_not_self`, unique `uq_biz_dependency_pair` (one definition per pair, whatever the rule).
- API: `GET /biz/{biz_id}/dependencies` (both directions, open) · `POST /biz/{biz_id}/dependencies`
  `{upstream_biz_id, match_rule, kind?}` (this biz = downstream; `@require_roles([ADMIN])`) · `DELETE
  /biz/dependencies/{id}` (admin; hard delete). Response `BizDependencyResponse {id, upstream, downstream: BizRef{id,
  business_code, name}, match_rule, kind, created_at}` (refs read with `include_deleted`).
- Service checks: self 400, other client 400, deleted / unknown biz 404 (`get_biz`), duplicate pair 409, cycle 400
  (`_creates_cycle`: DFS from downstream over all definitions, hard and informational). Created via the ORM (not
  `CRUDBase.create`: enums). No PATCH (change = delete + create) — mention if the UI needs it.
- `biz_dependency_repo` (`BizMaster.py`): `get_for_biz`, `get_pair`, `get_edges`. Migration drops the two enum types
  on downgrade.
- Tests `tests/test_biz_dependency.py` (4; client prefix `"G"`; guard checked via the OpenAPI x-staff-id param like
  `test_staff.py`). HTTP-checked on `plan_check`: new admin staff 8, new biz 2 `MOCK0002`; no staff 401, operator 403,
  admin 201, duplicate 409, cycle 400, delete 200.

**6.2 as built** (`OpeDependency` at the end of `src/domain_ope/models.py`, migration `cb0ae371f402`). User decisions
2026-11-04 (both as I recommended): **a deleted definition's links stay, marked removed** (`removed_at` +
`removed_reason`; FK `biz_dependency_id` ON DELETE SET NULL); **a missing upstream = a waiting row** with
`upstream_order_id` NULL (6.3 fills it when the upstream order appears). My call: `kind` / `match_rule` copied onto
the link (reuses the biz enum types `biz_dependency_kind_enum` / `biz_dependency_match_rule_enum`; the migration
uses `postgresql.ENUM(..., create_type=False)` and its downgrade leaves them to 6.1).
- Columns: `downstream_order_id` (FK RESTRICT), `upstream_order_id` (FK RESTRICT, nullable), `biz_dependency_id`,
  `upstream_biz_id` (FK biz_master RESTRICT: what is awaited even without an order), `kind`, `match_rule`,
  `match_sheet_event_id` / `match_date` (CHECK per rule), `removed_at` / `removed_reason` (CHECK both or neither),
  timestamps. CHECK not self. Partial unique (active rows only): `uq_ope_dependency_pair` (down, up) where up not
  null; `uq_ope_dependency_waiting` (down, upstream_biz) where up null. Not append-only (6.3 fills / removes rows).
- **For 6.3:** biz must not import ope, so marking links removed on a definition delete needs the coordination
  layer (e.g. the delete endpoint calling a coordination use case, or a hook like plan's slot listener).
- Tests `tests/test_ope_dependency.py` (3; client prefix `"L"`; listener off like `test_ope.py`).

**6.3 as built** (`src/domain_ope/links.py`, `src/domain_biz/dependency_events.py`; no migration). User decisions
2026-11-04 (all as I recommended, doc rev 57): **definition changes reach ope through a biz listener**
(`dependency_events.register_dependency_listener`, registered in `order_sync.register()` → `apply_dependency_change`;
`create_dependency` notifies "created" after flush, `delete_dependency` notifies "deleted" before the delete);
**only not-started downstream orders are (re)resolved** (pending / ready / on_hold from those); **a canceled upstream
stays linked** (live matches preferred, else the latest canceled; a returning slot's new order takes over — old row
removed with `REASON_UPSTREAM_CHANGED`); **no key → no link** (e.g. sheet rule on a non-sheet order).
- `links.resolve(db, order, dep)`: targets = `_upstream_targets` (upstream biz's orders with the same key via
  `ope_dependency_repo.get_orders_matching`); stale links removed, waiting rows filled with a found upstream (same
  row) or removed when others cover it, new rows for the rest, one waiting row when nothing matches.
- `links.refresh_order(db, order)`: one `biz_dependency_repo.get_for_biz` lookup first (returns at once for businesses
  without definitions — order creation is hot), then resolves the order as downstream and re-resolves downstream
  orders linked to it or matching its key. Called from `order_sync.create_order`, `_cancel`, `_slot_moved` (only when
  `occurrence_date` changes — one-offs), `ope.cancel_order`, `ope.resolve_conflict`.
- `links.definition_created` → all open orders of the downstream biz (`ope_dependency_repo.get_open_orders_of`);
  `definition_deleted` → every active link of it gets `REASON_DEFINITION_DELETED` (started orders' links too).
- Reasons (Japanese, stored): `依存関係の定義が削除されました` / `待つ上流のオーダーが変わりました` /
  `定義の突き合わせの条件に当てはまらなくなりました`.
- Tests `tests/test_order_links.py` (5; client prefix `"N"`; sheet case uses the mock sheet, marker 本締, offsets 0 / 1).
  HTTP-checked on `plan_check`: definition biz 2 → biz 1 (same date) gave 184 waiting rows (biz 2 has no orders);
  delete → 184 removed with the reason. Links aren't in any API response yet (6.4 / 6.5).
- Known flake seen again: `test_plan.py:69` client code collision (`uq_client_id`) ~1 run in 4.

**6.4 as built** (migration `58425e70286d`: `ALTER TYPE ope_order_event_type_enum ADD VALUE
'DEPENDENCY_OVERRIDE_APPROVED'`; downgrade recreates the type and drops / recreates `ck_ope_order_event_status_change`
and `ck_ope_order_event_created`). User decisions 2026-11-04 (both as I recommended, doc rev 58): **force-start =
approve, then the operator starts** (like early start); **the override doesn't lift the scheduled-day rule**. My
calls: met = upstream FINISHED only (waiting row, canceled, on hold, ready, in progress all block); informational
never blocks; the approval covers the links unmet **at approval time** (`detail.links` ids, `detail.blockers` text) —
a re-pointed / new link needs a new approval.
- `POST /ope/orders/{id}/approve-dependency-override` (releaser / admin, `OrderReasonIn`; pending or ready): 400 when
  nothing is unmet, 409 when all unmet links are already covered.
- `start_order`: after the day check, `links.unmet_hard_links` minus covered ids → 400 `Order N waits for: order M of
  CODE is pending; no order of CODE for 2026-11-08. A releaser or admin can approve starting without them.`; the
  start event `detail.dependency_override` lists the overridden link ids (and `early_start` as before).
- `OrderDetailResponse.dependencies` (`OrderDependencyResponse {id, kind, match_rule, upstream_biz {id,
  business_code, name}, upstream_order_id, upstream_status, upstream_scheduled_start, met, overridden}`) — active links
  where this order is downstream (downstream view for 6.5 still to add).
- Frontend: only `ORDER_EVENT_LABEL.dependency_override_approved` (依存関係を待たない開始を承認) so the build passes;
  types regenerated. **Until 6.5 the drawer offers 開始 even when dependencies block (backend 400s)** and has no
  override button.
- Tests `tests/test_dependency_start.py` (5; client prefix `"Q"`); `test_order_links.py`'s started-order test now
  approves an override first. HTTP-checked on `plan_check`: definition 3 (biz 2 → biz 1, deleted afterwards), order
  75: start 400 with the blocker, operator override 403, empty reason 422, releaser override 200, start 200
  (`detail {"early_start": true, "dependency_override": [254]}`).

**6.5 as built** (no migration). User decision 2026-11-04: **a new settings page** `/settings/dependencies?client=`
(nav 「業務の依存関係」), not a section on the template page.
- Backend additions: `GET /biz/clients/{client_code}/dependencies` (`biz_dependency_repo.get_for_client`; path chosen
  because `/biz/dependencies` would hit `GET /biz/{biz_id}`); `OrderDetailResponse.dependents`
  (`OrderDependentResponse {id, kind, downstream_biz, downstream_order_id, downstream_status,
  downstream_scheduled_start}`, via `ope_dependency_repo.get_active_by_upstream`); `DailyOrderSummary.blocked`
  (`links.blocked_order_ids`: not-started orders with an unmet, un-overridden hard link — a few queries for the whole
  day via `get_active_for_orders` + `ope_order_repo.get_events_of_type`); `links.overridden_link_ids` (services
  aliases it). Test `test_dashboard_blocked_flag_dependents_and_client_list` in `tests/test_dependency_start.py`.
- Frontend: `domain/biz/{types (BizDependency…), api/dependencyApi.ts (listForClient / create / remove),
  lib/dependencies.ts (MATCH_RULE_LABEL 同じシート日付 / 同じ日付 + help, KIND_LABEL 待つ / 参考 + help,
  canManageDependencies = active admin)}`; `features/dependency-settings/DependencySettingsPage.tsx` (client select in
  `?client=`, table 上流 → 下流 / 突き合わせ / 種類 / 登録日 / 削除 (admin), 依存関係を追加 modal with upstream /
  downstream selects of that client's businesses, rule and kind radios with help text, delete confirm).
  `domain/ope`: types `OrderDependency` / `OrderDependent`, `orderApi.approveDependencyOverride`,
  `orderActions`: action `approveDependencyOverride` (releaser / admin, reason required; pending / ready while
  `blockingDependencies(order)` is non-empty), 開始 hidden while blocked, `startBlockedReason` explains it.
  `OrderDrawer`: section 「依存関係」 (待つ上流のオーダー: biz, #id, status tag, 完了 / 待ち / 承認済み / 未完了, 参考
  tag; このオーダーを待つ下流のオーダー), override note in the modal. Dashboard rows: orange 「待ち」 tag when `blocked`.
  CSS `.order-deps`, `.order-dep`.
- Checked: `npm run build`; esbuild harness `deps_harness.ts` of the real modules against uvicorn 8001 on
  `plan_check` (order 76): operator create 403 + UI hides, admin create + listForClient, blocking waiting row, override
  offered to the releaser, 開始 hidden for the operator, blocked reason, dashboard 待ち true → override → false, start,
  delete — 14/14 passed. **Not checked: the browser** (the new page, the drawer section, the tag) — the user clicks
  through.
7. Client events with automatic completion (signals). **built** (7.1–7.5, branch `feature/ope-signals`)

#### Phase 7 decisions (2026-11-04, doc rev 62)
All four as I recommended: Phase 6 merged first, Phase 7 on a new branch; **a client event = a LIGHTWEIGHT business**
with its own template / orders (a file feeding several jobs = they depend on that business via Phase 6 links);
**transport: HTTP `POST /ope/signals` only**, sender = a staff account with a new role **`signal_sender`** (X-Staff-Id
until real login; watchers later = scripts posting the same signal); **match = signal type + client + rule date**
(`key` = the order's `occurrence_date` YYYY-MM-DD); none or several matches → stored unmatched for a person.

#### Phase 7 step plan (approved 2026-11-04)
| # | Step | Status |
|---|---|---|
| 7.1 | biz `execution_type` (SOP / LIGHTWEIGHT), `completion_mode` (MANUAL / AUTOMATIC), `signal_type` (required for AUTOMATIC); biz PATCH; migration; LIGHTWEIGHT orders get no steps at release; migration `6a7849dbf2ec` | **done** (`0ff76dd`, not pushed) |
| 7.2 | `ope_signal` table (append-only: type, client_code, key, received_at, sender, match result + order) + role `signal_sender` — tables / role only; migration `3242f180527a` | **done** (`a9f8fc3`, not pushed) |
| 7.3 | `POST /ope/signals` (signal_sender): store every signal, match, finish the order (system event); unmatched / ambiguous kept; manual way out (finish with reason) for AUTOMATIC | **done** (`0b5e762`, not pushed) |
| 7.4 | Read side: "late" computed on the dashboard, unmatched signals listed (`GET /ope/signals`) | **done** (`a7e1e03`, not pushed) |
| 7.5 | Frontend: client-event settings on a business, 受領 (mark received) in the drawer, late tag, unmatched signals panel | **done** (merged into `main`, not pushed) |

**7.1 as built** (migration `6a7849dbf2ec`). User decisions 2026-11-04 (both as I recommended, doc rev 63): **signal
type unique per client** (partial unique index `uq_biz_client_signal_type_alive` on (client_code, signal_type) where
not null and `deleted_at IS NULL`); **AUTOMATIC only for LIGHTWEIGHT**.
- `biz_master`: `execution_type` (`ExecutionType` SOP default | LIGHTWEIGHT; `biz_execution_type_enum`),
  `completion_mode` (`CompletionMode` MANUAL default | AUTOMATIC; `biz_completion_mode_enum`), `signal_type`
  (String 50). CHECKs `chk_biz_automatic_completion_lightweight`, `chk_biz_signal_type` (AUTOMATIC ⇔ signal type set).
  Migration creates the enum types first and the CHECKs by hand (both autogenerate gaps again).
- `BizMasterUpdate`: the three fields (explicit null refused for the two enums via `NOT_NULL_FIELDS`; `signal_type`
  stripped, null clears it); `BizMasterResponse` carries them. `update_biz` → `_check_client_event_settings` on the
  merged values: 400 (AUTOMATIC on SOP / AUTOMATIC without signal type / signal type with MANUAL), 409 (signal type used
  by another business of the client, message names it). `PATCH /biz/{id}` stays unguarded like before.
- `steps.plan_steps` returns no steps for LIGHTWEIGHT businesses (preview, release, step-set checks).
- Tests `tests/test_client_events.py` (4; client prefix `"E"`). HTTP-checked on `plan_check` (biz 2 left back at SOP /
  MANUAL). Frontend types regenerated (no UI yet — 7.5).
- Shell gotcha seen: `sed -n … $f` with an empty `$f` reads stdin and hangs the command — guard with `[ -n "$f" ]` /
  `< /dev/null`. And never combine `python - <<'EOF'` with `< /dev/null` (the redirect replaces the heredoc → an
  interactive REPL that hangs). Edit scripts go into the scratchpad via the Write tool.

**7.2 as built** (`OpeSignal` at the end of `src/domain_ope/models.py`, migration `3242f180527a`). User decisions
2026-11-04 (all as I recommended, doc rev 64): **store every signal; a resend whose order is already finished =
`DUPLICATE`** (no idempotency key); **optional JSON `payload`** (never used for matching); **`handled_*` settable once**
(trigger, no separate table).
- Columns: `signal_type` (50), `client_code` (String 10, **no FK** so unknown clients are kept), `key` (100),
  `received_at` (sender's), `recorded_at` (server), `sender_staff_id` (FK staff), `payload` JSONB, `result`
  (`SignalResult` MATCHED | DUPLICATE | UNMATCHED | AMBIGUOUS; `ope_signal_result_enum`), `matched_order_id` (FK
  ope_order RESTRICT), `result_note`, `handled_at` / `handled_by_staff_id` / `handled_note`. CHECKs:
  `ck_ope_signal_matched_order` (matched / duplicate ⇔ order), `ck_ope_signal_handled` (all three or none),
  `ck_ope_signal_handled_unmatched` (handled only for unmatched / ambiguous). Indexes `ix_ope_signal_open` (result,
  handled_at), `ix_ope_signal_client_type`.
- Trigger `trg_ope_signal_guard` → `ope_signal_guard()`: DELETE refused; UPDATE refused once handled, or when any
  non-handled column changes (row compare with IS DISTINCT FROM). Also installed by `create_all` (models.py DDL).
- Role `signal_sender` (信号の送信): `RoleCode.SIGNAL_SENDER`, `ROLE_SEED`, migration INSERT … ON CONFLICT DO NOTHING
  (downgrade deletes it; fails if a staff still holds it). `test_staff.py::test_roles_are_seeded` updated.
- Tests `tests/test_ope_signal.py` (3; client prefix `"H"`). Frontend types regenerated.

**7.3 as built** (`src/domain_ope/signals.py`; no migration). User decisions 2026-11-04 (all as I recommended, doc rev
65): **a signal finishes only ready / in-progress orders** (pending → unmatched "not released yet"); **on hold /
conflict → unmatched** with the reason; **handle endpoint** for people. My call: **LIGHTWEIGHT orders can be finished
from ready** (受領 = mark received; no start, so no day / dependency check for them).
- `POST /ope/signals` (`@require_roles([SIGNAL_SENDER])`, `SignalIn {type, client_code, key, received_at (tz
  required), payload? (≤ 10 000 bytes JSON)}`, 201 → `SignalResponse`): client code upper-cased; `_match` = AUTOMATIC
  business with (client, signal_type) → `date.fromisoformat(key)` → non-canceled orders of that business on that
  `occurrence_date` (FOR UPDATE): none → unmatched; all finished → DUPLICATE (latest finished order); >1 open →
  AMBIGUOUS; the one open order: conflict / on hold / pending → unmatched, else MATCHED → `finish_by_signal`
  (STATUS_CHANGED → FINISHED, SYSTEM, `detail {"cause": "signal", "signal_id"}`). The signal row is flushed first so
  the event can carry its id.
- `POST /ope/signals/{id}/handle` (operator / releaser / admin, `SignalHandleIn {note, order_id?}`): only unmatched /
  ambiguous, once (400 otherwise); with `order_id` the order must be the signal's client's (404) and ready / in
  progress (400) → finished as HUMAN with `detail {"cause": "signal handled", "signal_id"}` and `reason` = note.
- `finish_order`: LIGHTWEIGHT allowed from READY or IN_PROGRESS; AUTOMATIC businesses need a non-empty comment (400).
- Tests `tests/test_signals.py` (6; client prefix `"J"`). HTTP-checked on `plan_check`: new signal_sender staff 9 / 10,
  **biz 2 `MOCK0002` is now LIGHTWEIGHT + AUTOMATIC `data_received` with daily template 23** (left that way for 7.4 /
  7.5); order 194 (11/07): signal before release unmatched, operator 403, after release matched → finished (SYSTEM,
  signal 2), resend duplicate, handle once 200 / again 400.
- Gotcha: plan template API wants `template_type: "rrule"` (lowercase value).

**7.4 as built** (no migration). User decisions 2026-11-04 (both as I recommended, doc rev 66): **late = past
`scheduled_end` and not finished / canceled**; **all orders** (not only client events).
- `links.is_late(order, now)` (one rule); `OrderResponse.late` (detail, via `ope._now`), `DailyOrderSummary.late`
  (dashboard, via `ops_services._now`; `now` computed once per request).
- `GET /ope/signals?scope=open|all&client_code=&since=&limit=` (`@require_active()`; open = unmatched / ambiguous and
  not handled; newest first; client code upper-cased) → `signals.list_signals`.
- Tests added to `tests/test_signals.py` (late with `_now` monkeypatched past the end; list scope / client filter /
  handled drops out). HTTP-checked on `plan_check`: **unmatched signal 4 (bad key) left open for 7.5's panel**; 11/02
  orders show `late: true`.

**7.5 as built** (no migration). User decision 2026-11-04: **a 「業務の設定」 panel on the template settings page**
(`/settings/templates?biz=`) holding the release settings (Phase 4, had no screen) and the client-event settings.
- Backend: `OrderDetailResponse.execution_type` / `completion_mode` (from the business).
- Frontend: `domain/biz`: types `BizMasterUpdate` / `ReleaseMode` / `ExecutionType` / `CompletionMode`,
  `bizApi.update` (PATCH), `lib/settings.ts` (labels, `clientEventError` = backend rules, `clientEventBody` drops the
  signal type unless LIGHTWEIGHT + automatic); `features/plan-settings/BizSettingsPanel.tsx` (Descriptions + 編集
  modal: release mode / days before / time, execution type, completion mode + signal type only when LIGHTWEIGHT).
  `domain/ope`: types `Signal` / `SignalResult`, `api/signalApi.ts` (listOpen, handle), `hooks/useOpenSignals.ts`,
  `lib/signals.ts` (labels, `canHandleSignals` = operator / releaser / admin); `orderActions`: 完了 offered from ready
  for LIGHTWEIGHT, `finishLabel` (受領 for LIGHTWEIGHT), `finishNeedsReason` (automatic). `OrderDrawer`: 遅れ tag,
  顧客側の出来事 tag, 受領 label, reason required + note for automatic. Dashboard rows: red 「遅れ」 tag.
  `features/daily-dashboard/SignalsPanel.tsx` above the client cards (only when there are open signals and the acting
  staff is active): table 受信 / 顧客 / 信号の種類 / キー / 結果 + note, 対応 modal (order number optional, note required).
  CSS `.biz-settings`, `.signals-panel`.
- Checked: `npm run build`; esbuild harness `ce_harness.ts` against uvicorn 8001 on `plan_check` (order 196 of biz 2,
  signal 4): settings rules, save manual / automatic, open list, 受領 offered from ready with a reason, handle with
  the order → finished and gone from the list, late on 11/02 — 14/14 passed. **Not checked: the browser.**
- Incident: a typo (`newline="\\n"`) in an edit script raised after `open(..., "w")` had already **emptied
  `frontend/src/styles.css`**; restored from HEAD with `git checkout` (no uncommitted CSS changes existed) and
  re-applied the 2 new lines. Lesson: build the full text first, then write.

### UX shortcuts (branch `feature/ux-shortcuts`, 2026-11-05; not in the design doc — UI only)
User's ideas; all choices as I recommended.
| # | Step | Status |
|---|---|---|
| U.1 | Calendar day: double-click → `/daily?date=`; 「日次ダッシュボードで開く」 link in the selected-day panel | **done** (`9b7cb38`) |
| U.2 | Dashboard rows: ⚙ link (all users, also rows without an order; not voided rows) → `/settings/templates?biz=&template=` (row highlighted + scrolled into view); 「← 戻る」 links via router state (`shared/lib/returnTo.ts`, `shared/ui/ReturnLink.tsx`): dashboard → calendar (same client / month, day re-selected via `state.selectDate`), template page → dashboard day; state kept across day / business changes, chains (calendar → dashboard → template) | **done** (`f002f9f`) |
| U.3 | Template page edits need `admin` (業務管理者; not system_admin): `@require_roles([ADMIN])` on plan template writes (create / patch / delete / restore / dates / cache rebuild) and `PATCH /biz/{id}`; UI hides 新規作成 / 編集 / 削除 and the 業務の設定 編集 for non-admins (panel stays visible). The user's staff 1 has no admin role → must grant it | **done** (`34914a8`) |
| U.4 | Branch `feature/admin-guard` (from `main` `d6ad461`). User's choices as I recommended: sheet dates, holidays / calendars, remaining biz writes (biz create / delete / restore, SOP version clone / approve / cancel / create, step templates) → `admin`; **calendar occurrence changes (変更 / 取消 / 臨時 / ルールに戻す / 取消の復元) → releaser or admin** (they move / cancel / create orders; closes the loophole of an operator moving an order to today and starting it without the early-start approval). No `require_active` left in plan. `auth._guard` sets `__required_roles__` on the wrapper (test marker). `tests/test_plan_settings_guard.py` checks every `/plans` + `/biz` route (writes: header + exact roles; reads open; walks `plan_router.routes` / `biz_router.routes` — `app.routes` holds `_IncludedRouter`s in this FastAPI). UI: sheet / holiday pages hide edits for non-admins (「変更は業務管理者だけができます」); calendar shows no actions / 臨時 for non releaser-admin (`domain/plan/lib/permissions.ts` `canChangeOccurrences`); 取消済みの予定 list without 元に戻す. Operators: dashboard work only | **done** |

### Phase L — "latest before due" (branch `feature/latest-before`, 2026-11-05)
User's decisions: compare by **scheduled start** (not rule date); a **canceled latest upstream stays awaited**;
**look-back limit in days on the definition** (my alternative recommendation was no limit). Doc rev 72 (paragraph
after "Link resolution" + ticked open question).
| # | Step | Status |
|---|---|---|
| L.1 | `DependencyMatchRule.LATEST_BEFORE`; `biz_dependency.lookback_days` (1–366, required ⇔ latest_before; CHECKs use `match_rule::text` because a new enum value can't be used in the same transaction); create API / response; migration `2f7614f1cb02` (downgrade rebuilds the shared enum type and the ope CHECKs) | **done** (`bfaab32`) |
| L.2 | `links._targets_for`: latest upstream order with `scheduled_start` in [own start − lookback, own start] (canceled included; tie → higher id), no match key stored, else a waiting row (`describe`: "no order of CODE in the N days before it"); `refresh_order` re-resolves not-started downstreams starting within lookback after an upstream order; `order_sync._slot_moved` refreshes on any time change (not only rule-date change); repo `get_latest_starting_before`, `get_open_orders_of(starting_from/until)`; `tests/test_latest_before.py` (client prefix `W`, weekly → daily) | **done** (`c653251`) |
| L.3 | 業務の依存関係: option 直前の上流 + required 日数 input (default 35, `DEFAULT_LOOKBACK_DAYS`), table text 「直前の上流（35日前まで）」 (`matchRuleText`), body via `dependencyBody`; drawer hint 「（直前の上流）」 | **done** |

### Phase N — deadlines and "due soon" (branch `feature/deadlines`, 2026-11-05, merged into `main`)
Why: the person checking client files in WinSCP needs a warning before the deadline, not only 遅れ after it.
User's decisions: **deadline per template, 3 modes** — `END` (scheduled end, default), `OFFSET` (minutes after the
*scheduled* start; internal steps), `FIXED_TIME` (local time on the scheduled day + 0–7 days; external hard
cut-offs); **warning lead on the template, default 0 = off** (avoid alert fatigue); dashboard first (まもなく tag +
panel + auto-refresh), no messages yet; all not-finished orders. **The user insisted (blocker): `deadline_at` is
stored on the order** (not computed on read) for SLA + polling performance; **the rule is fixed at release** (template
edits re-stamp only 未リリース orders; released / running / finished never change; moves recompute from the order's
own rule snapshot); **`finished_at` stored on the order** for SLA. Doc rev 73 (bullet after "Late").
| # | Step | Status |
|---|---|---|
| N.1 (`2e5228f`) | plan_template `deadline_mode` (`plan_deadline_mode_enum`), `deadline_offset_minutes` (1–10080), `deadline_time` + `deadline_day_offset` (0–7), `warn_before_minutes` (0–1440, default 0); CHECKs; schemas (`deadline_problem` shared); service: deadline fields don't bump revision / regenerate, mode switch clears unused fields, fixed time ≤ start on day 0 → 400; migration `d17d631f5ad2`; `tests/test_template_deadline.py` (prefix `F`); frontend create body sends defaults until N.4 | **done** |
| N.2 (`503f3c6`) | ope_order: rule snapshot (`deadline_mode` reuses `plan_deadline_mode_enum`, offset, time, day offset, `deadline_timezone`, `warn_before_minutes`) + `deadline_at` (NOT NULL) + `warn_at` + `finished_at`; CHECKs (rule, warn_at ⇔ warn, finished_at ⇔ FINISHED); `domain_ope/deadlines.py` (`copy_rule`, `compute`, `restamp`; fixed time = local date of scheduled_start + days); stamped in `order_sync.create_order`, `_slot_moved`, `resolve_conflict` accept_plan; `finished_at` set in `ope_order_repo.add_event` when to_status FINISHED; migration `c5bb40015e61` with backfill; `tests/test_order_deadlines.py` (prefix `Y`); direct-ORM tests pass END defaults | **done** |
| N.3 (`95c94fe`) | `domain_plan/template_events.py` (listener; `update_template` notifies when deadline fields or timezone change) → `order_sync.apply_template_deadline_change` re-stamps orders with `released_at IS NULL` (not canceled; `ope_order_repo.get_unreleased_of_template`); `links.is_late` = `deadline_at` < now, `is_due_soon` = `warn_at` ≤ now < `deadline_at`; order detail + dashboard rows carry `deadline_at` / `due_soon` (+ detail: `deadline_mode`, `warn_at`, `finished_at`); **`GET /ops/attention?limit=`** (open orders late or due soon, any day, earliest deadline first, `truncated`; `ope_order_repo.get_needing_attention`); migration `51d8d829a2d2` (partial indexes `ix_ope_order_open_deadline`, `ix_ope_order_open_warn`). Timings on plan_check: `/ops/daily` ~24 ms median, `/ops/attention` ~11 ms | **done** |
| N.4 (`7ab2cc3`) | frontend: `domain/plan/lib/deadline.ts` (labels, `describeDeadline`); `templateForm.deadlineFields` (unused fields null, fixed day default 0) + template modal section 締切 (mode radio, 分後 / 予定日の N日後 + 時刻, 何分前 default 0) + list column 締切; `domain/ops` `getAttention` + `useAttention`; `features/daily-dashboard/AttentionPanel.tsx` (shown only when items; row → drawer); rows: まもなく (gold) + 「締切 HH:mm」 when it differs from the end (`deadlineLabel`, `showsOwnDeadline`); drawer: 締切 line, まもなく tag, 完了 line + 締切後 tag; `shared/hooks/useAutoRefresh` — dashboard + attention every **2 min** while the tab is visible (and on return) | **done** |
**Dashboard tabs (2026-11-05, user feedback "the late box makes it dirty", branch `feature/dashboard-tabs`):** 日次ダッシュボード = Tabs 予定 (default) / 締切・遅れ (count badge: red if any late, else gold) / 信号 (orange); `?tab=attention|signals` in the URL (kept across day changes and the back-link state); no big alert — one summary line + Empty states; open signals fetched in the page (`useOpenSignals`) for the badge, refreshed with the 2-min auto-refresh.
**SLA report (2026-11-05, branch `feature/sla-report`):** user's figures — 完了 / 遅れ / 期限内率 / 平均遅れ（分）, grouped by client × month; decisions (all as I recommended): **month of the deadline (JST)**, **average over late orders only**, extra column **未完了の遅れ** (open past deadline, not in the other figures), **any active staff**. S.1 `aae5c50`: `GET /ops/sla?from=YYYY-MM&to=YYYY-MM&client_code=` (`coordination.services.get_sla_report`, one GROUP BY over `ope_order` stored `deadline_at` / `finished_at`; canceled excluded; default last 12 months, max 36; `tests/test_sla_report.py` prefix `U`). S.2: nav 「SLA」 → `/reports/sla?from=&to=&client=` (`features/sla-report`: month range + client filter, table with 合計 rows for months with 2+ clients — late-weighted average, CSV of the shown rows with BOM, `sla_<from>_<to>[_<client>].csv`).
Random client-code flake seen twice in Phase N (once unidentified, once `YCFD` in `test_order_deadlines.py`) → **fixed
2026-11-05: `tests/client_codes.py` `new_client_code(prefix)`** (per-prefix shuffled pool, no repeats within a run) used by all
21 test files (branch `fix/test-client-codes-all`). Use it in every new test file. Before: the other
test files still draw `prefix + 3 hex` at random → proposed: move `test_plan.py`'s unique pool into a shared test module.

### M1 — client + business master data (branch `feature/master-screens`, 2026-11-06; doc rev 79)
User's decisions (all as I recommended): **business delete refused while in use** (dependency definitions, live plan
templates, orders not finished / canceled — past-dated open orders count too); **inactive client = hidden from
`GET /clients/` (unless `include_inactive=true`) + no new businesses / sheets / business restores**, history stays;
**`GET /biz/?client_code=&include_deleted=`**. Earlier: clients never deleted; business code automatic and fixed.
**M1.1 as built** (no migration — `client_master.is_active` already existed):
- Client: `ClientCreate.code` pattern `^[A-Za-z0-9]{4}$` (upper-cased), name 1–100; `ClientUpdate` = name only,
  `extra="forbid"` (sending `code` → 422); `ClientResponse` + `is_active`, `created_at`, `updated_at`. Endpoints:
  `GET /clients/?include_inactive=` (open, code order) · `POST /clients/` 201 · `PATCH /clients/{id}` ·
  `POST /clients/{id}/deactivate` · `POST /clients/{id}/activate` (all writes `@require_roles([ADMIN])`);
  **`DELETE /clients/{id}` removed** (405). `client_services.require_active_client(db, code, lock=)` (404 / 400 inactive)
  used by biz create / restore and plan `create_sheet` / `import_sheet`.
- Business: `BizMasterCreate.business_seq` optional, 1–9999 (LPAD 4 would truncate 10000); omitted → client's max seq
  **including deleted** + 1, client row locked `FOR UPDATE`; explicit number used by a live / deleted business → 409
  (DB already had a global unique `biz_master_business_code_key`). `delete_biz` → 400 listing reasons; `restore_biz`
  needs an active client.
- Hooks (client / biz must not import biz / plan / ope): `domain_client/deactivation_checks.py`,
  `domain_biz/delete_checks.py`; checks registered by `src/coordination/master_guards.py` (`register()` called from
  `order_sync.register()`): alive businesses of the client; live templates (`plan_template_repo.get_by_biz`);
  unfinished orders (`ope_order_repo.count_unfinished_of_biz`). Repos: `client_repo.get_list` / `get_locked` /
  `get_locked_by_code`, `biz_master_repo.get_list` / `max_business_seq` / `count_alive_of_client`.
- Tests `tests/test_master_data.py` (6; client prefix **`C`**). HTTP-checked on `plan_check` (24/24): **new client
  `Z8E4` (id 2) with business `Z8E40001` live, `Z8E40002` / `0003` deleted**; MOCK0001 delete refused ("18 plan
  template(s); 186 order(s) …"). Frontend types regenerated; no UI yet (M1.2). Committed `2729ea7`.

**M1.2 step plan (approved 2026-11-06).** User's decisions (all as I recommended): business number **automatic with a
preview** in the 登録 modal (no number field; API still accepts one for a load script); nav = **「設定」 dropdown**;
業務 page edits **basics (名前 / 管理者メール / 説明) + a link** 「予定テンプレート・業務の設定」 → `/settings/templates?biz=`
(release / client-event settings stay in that page's 業務の設定 panel).
| # | Step | Status |
|---|---|---|
| M1.2a | `AppLayout`: カレンダー / 日次ダッシュボード / SLA flat; antd `Dropdown` 「設定」 (hover + click) with the 5 settings pages (`SETTINGS_PAGES`), button shows 「設定：<page>」 + active style when one is open (`currentSettingsPage`); links keep each page's last query string; CSS `.nav-menu*`. 顧客 / 業務 entries are added in M1.2b / c | **done** (`5a619b6`) |
| M1.2b | 顧客 page `/settings/clients` (`features/client-settings`: `ClientSettingsPage` + `ClientFormModal`; `clientApi` create / update / deactivate / activate, `list(signal, includeInactive)`; `useAllClients`; `domain/client/lib/clients.ts` `canManageClients` (active admin), `normalizeClientCode`, `clientCodeError` (4 alnum, not used — inactive included), `deactivateBlockedReason`). Table コード / 顧客名 / 状態 / 業務 (count of live businesses; becomes a link in M1.2c) / 登録日 / 操作 (admin: 名前を変更, 無効にする — disabled with the reason while businesses remain — / 有効にする, confirm; backend message shown on refusal); inactive rows greyed (`is-past-row`); first entry of the 設定 menu. Harness 15/15 on plan_check (client `YA64` id 3 left active, its business deleted) | **done** (`2cfb5fa`) |
| M1.2c | 業務 page `/settings/businesses?client=` (`features/business-settings`: `BusinessSettingsPage` + `BizFormModal`; `bizApi.listForClient(code, includeDeleted)` / `create` / `remove` / `restore`; `domain/biz/lib/businesses.ts` `canManageBusinesses` (active admin), `nextBusinessCode` (max seq incl. deleted + 1, null past 9999), `bizBasics` (blank → null), `bizUpdateBody` (changed fields only)). Client field like 業務の依存関係 (active clients; warning when `?client=` is inactive / unknown → no 登録 / 元に戻す). Table 業務コード / 業務名 (+ description) / 管理者メール / 状態 有効 / 削除済み / 操作: 「予定テンプレート・業務の設定」 (all users, live rows; navigate to `/settings/templates?biz=`), admin: 編集, 削除 (confirm; backend's in-use reasons shown 10 s), 元に戻す. 登録 modal shows the code it will get. 顧客 page 業務 column = link to this page; 業務 = 2nd entry of the 設定 menu; CSS `.biz-description`. Harness 16/16 on plan_check (YA64 now has YA640002 live, YA640001 deleted) | **built, uncommitted** |

### M2 — SOP screens (branch `feature/sop-screens` from `main` `44c1737`, 2026-11-06; doc rev 80)
Found first: the stored SOP status never moved FUTURE → ACTIVE (nothing promoted it), so a second approval was always
refused ("既に別の予約…") and 予約の取消 could turn an in-use version back into an editable draft. User's decisions (all
as I recommended): **states from dates**; **新しい版 copies the newest approved version** (scheduled one if any, else
current; empty draft for the first SOP); **effective = a date, from 00:00 JST**. My calls (user didn't object):
approving a draft with **no steps is refused**; **no four-eyes** on SOP approval (editors aren't recorded).
| # | Step | Status |
|---|---|---|
| M2.1 | Version states from dates + approve / cancel rules; migration `7a3c5e9b1d24` | **done** (`5b054ea`) |
| M2.2 | Draft editing API (as built below) | **done** (`ce85e39`) |
| M2.3 | `GET /ope/sop-impact` (as built below) | **done** (`2582eaa`) |
| M2.4 | SOP page (as built below) | **done** (`f549312`) |
| M2.5 | Draft step editor (as built below) | **done** (`800061c`) |
| M2.6 | Approve dialog + 予定を取り消す (as built below) | **built, uncommitted** |

**M2.1 as built** (migration `7a3c5e9b1d24`: rebuilds `sop_status_enum` as DRAFT / APPROVED — FUTURE / ACTIVE / ARCHIVED →
APPROVED; data fix-up first: drafts lose their dates, approved without `effective_at` get now, open-ended approved
versions are chained to the next one's `effective_at` (LEAD by effective_at); CHECKs `ck_sop_version_effective_iff_approved`
(draft ⇔ no effective_at), `ck_sop_version_expired_after`; downgrade maps back by dates).
- `SOPStatus` DRAFT | APPROVED; `SopState` draft | scheduled | current | past via `SOPVersion.state_at(now)` / `.state`;
  `SOPVersionResponse` + `state` (and `model_config`); `SOPVersionScheduleIn.effective_date` (was `effective_at`).
- `approve_and_schedule_version(db, biz_id, draft_id, effective_date)`: locks the biz row; date must be > today JST;
  draft of this biz with ≥ 1 step; refused while another version is scheduled; every approved version with
  `expired_at` NULL gets `expired_at = effective_at` (exact, no −1 s); draft → APPROVED. `cancel_future_version`: approved
  + scheduled only, else 400 "already taken effect"; `version_checks.reasons_not_to_cancel` (new hook
  `src/domain_biz/version_checks.py`, registered by `master_guards.version_used_by_orders` →
  `ope_order_repo.count_using_sop_version`: pinned or frozen, not canceled); versions ending at its start reopen; → DRAFT.
  Removed dead `create_sop_version` / `get_latest_active_version`. `LOCAL_TIMEZONE` in biz services.
- **Fixed a latent bug:** git stored `src/infrastructure/repositories/client.py` while `__init__` imports `.Client`; it
  only worked because the working-tree file was `Client.py`. A branch switch rewrote it lowercase →
  `ModuleNotFoundError`. Renamed in git to `Client.py` (a fresh clone / Linux would have failed).
- Tests: `tests/test_sop_versions.py` (4; client prefix **`X`**); six test files switched `SOPStatus.ACTIVE` /
  `FUTURE` → `APPROVED`. Round trip on plan_check (also with synthetic old-style rows: chain + draft cleanup OK, rows
  removed). HTTP 10/10 on plan_check: v9 = current; draft id 6 (`v9.1793927904.0`, 1 step) left on biz 1 after
  approve → cancel.

**M2.2 as built** (no migration). Endpoints (writes `@require_roles([ADMIN])`, reads open):
`GET /biz/{id}/versions?include_drafts=` (default approved only = pin choices; newest first by version_number) ·
`GET /biz/versions/{id}` → `SOPVersionDetailResponse` (version + `steps` by number) · `POST /biz/{id}/versions/clone`
= **新しい版**: copies the newest approved version by `effective_at` (scheduled one if any), empty when none ·
`POST /biz/{id}/versions` (empty draft, kept) · `PATCH /biz/versions/{id}` (`SOPVersionUpdate` = tag, subclass of
`SOPVersionCreate`) · `DELETE /biz/versions/{id}` (draft + steps, hard) · `POST /biz/versions/{id}/steps`
(`step_num` optional → max + 1; title stripped, 1–100) · `PUT /biz/versions/{id}/steps/order` (`SOPStepOrderIn.step_ids`
= every step once → 1..n, two-phase via a high offset because of `uq_sop_version_step_num`) · `PATCH /biz/steps/{id}`
(`SOPStepTemplateUpdate`: title / content (null clears) / condition / is_blocking; explicit null refused for the
others) · `DELETE /biz/steps/{id}` (numbers kept; reorder to close gaps). All edits: approved version → 400
"…is approved and can no longer be changed"; the version row is locked `FOR UPDATE`. Services `list_versions`,
`get_version`, `_get_draft`, `rename_draft`, `delete_draft`, `update_step_template`, `delete_step_template`,
`reorder_steps`; `create_new_sop_version` now rolls back on a duplicate tag. Tests +3 in `tests/test_sop_versions.py`.
HTTP 14/14 on plan_check: draft id 6 renamed **`v9.1793927904.0-http`** (1 step) left on biz 1.

**M2.3 as built** (no migration; ope side, since biz must not read orders). `GET /ope/sop-impact?biz_id=&effective_date=&limit=`
(`@require_active()`, limit 1–500, default 50) → `SopImpactResponse {biz_id, effective_date, effective_at (00:00 JST),
will_switch, pinned, released}`, each `SopImpactGroup {total (exact), orders (earliest first, ≤ limit)}` of
`SopImpactOrder {id, template_id, template_name, scheduled_start, status, pinned_sop_version_tag,
frozen_sop_version_tag}`. Groups (orders of the biz scheduled ≥ effective_at, not finished / canceled):
**will_switch** = `released_at` null + not pinned; **pinned** = not released + pinned; **released** = released (ready /
in progress / on hold). `src/domain_ope/sop_impact.py` (`sop_impact(db, biz_id, effective_date, limit)`; joins
PlanTemplate with `include_deleted`). Tests `tests/test_sop_impact.py` (2; client prefix **`Z`**). HTTP 6/6 on
plan_check (biz 1, a week ahead: 158 / 0 / 1). Gotcha: a backgrounded command whose cwd drifted to `frontend/` ran
without its leading `cd` → start uvicorn with absolute paths (`/c/p/postgres-migration-poc/.env`, `.venv`, `LOG_FILE`).

**M2.4 as built** (frontend only). `/settings/sop?biz=&version=` (「SOP」 = 3rd entry of the 設定 menu; 「SOP」 button on
業務 rows for live SOP businesses — not LIGHTWEIGHT; page shows an info alert for LIGHTWEIGHT). Business select =
`bizOptions` (moved from PlanSettingsPage to `domain/biz/lib/businesses.ts`). Layout `.sop-layout` (grid: versions
left 280–360 px, steps right; one column under 900 px): versions table タグ / 状態 (草稿 / 予定 gold / 現行 green / 過去,
past rows greyed) / 有効期間, row click → `?version=`; default selection `defaultVersion` = current → scheduled →
newest. Right: tag + state + period, steps table 番号 / 手順 (title + 承認で次へ tag + content pre-wrap) / 含める条件
(`conditionText`: 毎回 / 3月・9月のみ / 週の最初の予定のみ). Admin: 「新しい版」 modal (`NewDraftModal`: says what it copies
via `newDraftSource`, tag prefilled by `suggestNextTag` = highest vX.Y.Z with Y+1, `VERSION_TAG_PATTERN`, duplicate check)
and 「草稿を削除」 (confirm). New: `domain/biz/api/sopApi.ts` (listVersions(bizId, includeDrafts), getVersion, newDraft,
deleteDraft), `domain/biz/lib/sop.ts` (`canManageSop` active admin, labels / colors, helpers above), types `SopState`,
`SopVersionDetail`, `SopStep`, `SopStepCreate`, `SopStepUpdate`. **`periodText`** in `sopVersions.ts` shows the last day
(expired_at − 1 ms, since expired_at = next version's start since M2.1); `pinOptions` in the order drawer uses it too.
CSS `.sop-layout`, `.sop-version-selected` (`--select`), `.sop-step-content`. Harness 17/17 on plan_check (draft created
and deleted again).

**M2.5 as built** (frontend only). On a **draft** (admin): header buttons タグを変更 (`RenameDraftModal`) / ステップを追加 /
草稿を削除; steps table gets 操作: ↑ / ↓ (swap via `movedStepIds` → `reorderSteps` = renumber 1..n), 編集, 削除 (confirm;
numbers kept); info alert + 「番号を振り直す」 when `hasNumberGaps`. `StepFormModal` (add / edit): 手順 (1–100), 内容,
含める条件 radio 毎回 / 指定した月だけ / 週の最初の予定だけ with help text (`CONDITION_LABEL` / `CONDITION_HELP`), month
checkboxes 1–12 (`.sop-months` grid of 6) required ≥ 1 (`conditionError`), 承認で次へ checkbox with explanation.
`sop.ts`: `conditionBody` (months deduped + sorted), `stepFormValues`, `stepCreateBody` (blank content → null),
`stepUpdateBody` (changed fields only, null when unchanged), `movedStepIds`, `hasNumberGaps`. `sopApi`: renameDraft,
addStep, updateStep, deleteStep, reorderSteps. Harness 16/16 on plan_check (draft id 6 `v9.1793927904.0-http` now has 2
steps).

**M2.6 as built** (frontend only; doc rev 81). Draft (admin): 「承認…」 button, disabled with the reason
(`approveBlockedReason`: draft only, ≥ 1 step, no other scheduled version) also shown as a line under the header.
`ApproveModal` (`destroyOnClose`): DatePicker from tomorrow (`firstEffectiveDate(todayIn(TIMEZONE))`), text "<date> 以降
… が <tag> を使います。現行の <tag> は <前日> までになります", impact via `sopImpactApi.get(bizId, date, 20)`
(`domain/ope/api/sopImpactApi.ts`, types `SopImpact*`) in three sections 新しい版を使うオーダー / 指定した版のまま /
リリース済み（固定した版のまま） with total, up to 20 orders (time, template, status tag, kept tag, #id) and 「ほか N 件」;
approve → `sopApi.approve(bizId, id, date)`. Scheduled version (admin): 「予定を取り消す」 (confirm; backend refusal e.g.
pinned orders shown 8 s) → `sopApi.cancelApproval`. CSS `.sop-impact*`. Harness 12/12 on plan_check (draft id 6 approved
for tomorrow, impact read, second approval 400, cancel → draft again; current v9 open-ended again). **Not checked in a
browser.**

### Login (branch `feature/login`, 2026-11-06; doc rev 82)
User's decisions (all as I recommended): **server-side DB sessions in an HttpOnly cookie, 12 h idle, max 7 days**
(logout / suspend / password change end them); **a system_admin sets a temporary password, the person must change it
at the next login**, everyone can change their own, 5 wrong tries → 15 min lock; **API key per signal_sender** for
`POST /ope/signals` (shown once, hashed, revocable); **X-Staff-Id removed entirely** (harnesses log in). My calls:
stdlib `hashlib.scrypt` (no new dependency), cookie `Secure` from a setting (off on plain-HTTP intranet), SameSite=Lax
as CSRF protection (same-origin app). Step names **LG.x** (L.x is the latest-before phase).
| # | Step | Status |
|---|---|---|
| LG.1 | Model + building blocks (no endpoint uses them yet); migration `b4e8d2a6c913` | **done** (`3a93ffd`) |
| LG.2 | Backend switch: `/auth/login` / `logout` / `password`, cookie in `get_current_staff`, X-Staff-Id removed, Bearer key on `POST /ope/signals`, must_change_password → 403 elsewhere, temporary password + API key endpoints (system_admin), suspend / password ends sessions, `create_staff.py` password prompt + `scripts/set_password.py`, guard tests; update the doc's X-Staff-Id paragraph | **done** (`c644b4d`) |
| LG.3 | Frontend (as built below) | **done** (`311c38e`) |

**LG.1 as built** (migration `b4e8d2a6c913`). `staff_user` + `password_hash` (String 255, null = cannot log in),
`must_change_password`, `failed_logins`, `locked_until`, `password_changed_at`. New `staff_session` (`token_hash`
unique SHA-256 hex, `last_seen_at`, `expires_at` = created + 7 d, `revoked_at`) and `staff_api_key` (`label`,
`key_prefix` = first 10 chars, `key_hash` unique, `created_by_id` / `revoked_by_id`, `last_used_at`, `revoked_at`); FKs to
staff RESTRICT (staff are never deleted). `src/domain_staff/credentials.py` (no commits; callers commit):
`hash_password` / `verify_password_hash` (format `scrypt$n$r$p$salt$hash`, n=2^14 r=8 p=1, `hmac.compare_digest`),
`password_problem` (8–128 chars, no edge spaces, ≠ login ID), `set_password(temporary, keep_session_id)` (clears lock,
ends the staff's other sessions), `authenticate` (row locked; unknown login still hashes once; 401
`INVALID_CREDENTIALS` "Login ID or password is wrong."; 5th failure → `locked_until` = now + 15 min, 403
`ACCOUNT_LOCKED` "…after HH:MM JST"; non-active → 403 `STAFF_NOT_ACTIVE` only after a correct password),
`create_session` (token `secrets.token_urlsafe(32)`), `resolve_session` (revoked / idle 12 h / max age → None; touches
`last_seen_at` at most once a minute), `revoke_session`, `revoke_all_sessions(except_session_id)`, `issue_api_key`
(signal_sender only, label required, key `ops_` + 32 random bytes), `resolve_api_key` (records `last_used_at`),
`revoke_api_key`. New `ErrorCode`s `PASSWORD_CHANGE_REQUIRED`, `ACCOUNT_LOCKED` (`INVALID_CREDENTIALS` existed).
Messages are English like the rest of the API; the login page maps codes to Japanese (LG.3). Tests
`tests/test_credentials.py` (6, no client). Round trip + `alembic check` on plan_check OK.

**LG.2 as built** (no migration). User decision 2026-11-06 (as I recommended): **login for everything** — every API
call needs a session (or the signal API key); open: `/auth/login`, `/auth/logout`, `/openapi.json` + `/docs`, `/`
(and the old `/test-error` in main.py).
- `src/domain_staff/auth.py`: `SESSION_COOKIE = "ops_session"`; `get_current_staff(request, db, session_token =
  APIKeyCookie, bearer = HTTPBearer)` (OpenAPI shows `security: APIKeyCookie / HTTPBearer`): session → staff and
  `request.state.session_id`; Bearer key only on **`API_KEY_ROUTES = {("POST", "/ope/signals")}`** (route path from
  `request.scope["route"]`); commits the touch; cached on `request.state.staff`; else 401 "Login required.".
  `require_login` (added to every router in `main.py`: `include_router(..., dependencies=[Depends(require_login)])`):
  non-active → 403 `STAFF_NOT_ACTIVE` except `GET /staff/me`; `must_change_password` → 403 `PASSWORD_CHANGE_REQUIRED`
  except **`PASSWORD_CHANGE_ROUTES`** (`GET /staff/me`, `POST /auth/password`, `POST /auth/logout`).
  `current_session_id(request)`. `require_roles` / `require_active` unchanged. **X-Staff-Id is gone.**
- `src/domain_staff/auth_router.py` (`/auth`, no global dependency): `POST /login` (`LoginIn`) → `StaffResponse` +
  cookie (HttpOnly, SameSite=Lax, Path=/, max-age 7 d, `Secure` if **`COOKIE_SECURE=1`** — new `settings.cookie_secure`,
  default false); `POST /logout` → 204, revokes + deletes the cookie (works without a session); `POST /password`
  (`PasswordChangeIn`; `Depends(require_login)`; wrong current → 401, same as current → 400; keeps this session).
- Staff router (system_admin): `PUT /staff/{id}/password` (`TemporaryPasswordIn`; not yourself → 400) · `GET /staff/{id}/api-keys`
  · `POST /staff/{id}/api-keys` (`ApiKeyCreate {label}` → 201 `ApiKeyIssuedResponse` with `key` once) ·
  `POST /staff/api-keys/{key_id}/revoke`. `set_staff_status` to non-active revokes the staff's sessions.
  `StaffResponse` + `has_password`, `must_change_password`, `locked_until` (model property `has_password`).
- Services `login` (commits failure counts even when it raises), `logout`, `change_own_password`,
  `set_temporary_password`, `list_api_keys`, `issue_api_key`, `revoke_api_key`.
- Scripts: `create_staff.py` asks for the password twice (getpass) and sets it (not temporary);
  **new `scripts/set_password.py <login_id> [--temporary]`** (getpass twice; clears lock, ends sessions).
- Tests: new `tests/openapi_auth.py` `needs_login(op)`; nine files' x-staff-id checks → `needs_login`; "reads stay
  open" → `test_reads_need_a_login_but_no_role`; `test_staff.py` `test_get_current_staff_reads_the_session_or_an_api_key`
  (fake starlette `Request` with `route`); new `tests/test_login.py` (4).
- **plan_check passwords** (set by my scratchpad `seed_passwords.py`, plan_check only): every staff id N has
  **`check-pass-N`** (e.g. 8 admin `http-admin-6eb1ee` / `check-pass-8`, 1 `check-admin` system_admin, 4 operator
  `http-operator-1793324910`, 5 releaser `http-releaser-1793324911`, 9 signal_sender `signal-bot-cc9a19`). HTTP 26/26
  (cookie flags, logout, temporary password flow, lock 5 → unlock via temporary, suspend ends session, API key issue /
  list / signal 201 / refused elsewhere / revoked). Left: one more unmatched signal `http_check`, a revoked key on staff 9.
- **Harness pattern from now on:** log in first (`POST /auth/login`, keep the cookie: Python `http.cookiejar`; node:
  read `set-cookie` and send `Cookie`).

**LG.3 as built** (frontend; backend only the 401 description text in `src/core/schemas/error.py`).
- **Removed:** `app/ActingStaffPicker.tsx`, `shared/api/actingStaff.ts`, `shared/hooks/useActingStaffId.ts`,
  `DEFAULT_STAFF_ID` / `VITE_DEFAULT_STAFF_ID` (config, vite-env.d.ts, .env.example); http.ts no longer sets a header.
- `shared/api/session.ts` (store `{version, signedOut}`; `markSignedIn` / `markSignedOut`) + `shared/hooks/useSession.ts`;
  http.ts `onResponse`: any 401 except `/auth/login` → `markSignedOut()`. `useCurrentStaff` / `useStaffList` /
  `useRoles` / `useSlaReport` re-fetch on `version` (no more `enabled: actingId !== null`).
- `AppLayout` = the login gate: `signedOut` or me 401 → `<Navigate to="/login" state={{from: location}} />`; loading
  spinner; other error → alert + reload; **`must_change_password` → full-page 「パスワードを変更してください」 card
  (`PasswordChangeForm`)** instead of nav + pages; else nav with **`UserMenu`** (name pill reusing `.acting-staff`
  CSS; menu: ログインID, パスワードを変更 (modal), ログアウト → `authApi.logout` + `markSignedOut` + `/login`).
- Route **`/login`** outside the layout (`features/auth/LoginPage.tsx`: ログインID / パスワード, error text by code via
  `domain/staff/lib/login.ts` `loginErrorText` (INVALID_CREDENTIALS / ACCOUNT_LOCKED with the HH:MM / STAFF_NOT_ACTIVE),
  success → `markSignedIn` + back to `state.from`; already logged in → redirect). `PasswordChangeForm` (current / new /
  confirm; `newPasswordProblem` mirrors the backend rules; `passwordChangeErrorText`).
- `domain/staff/api/authApi.ts` (login, logout, changePassword); `staffApi` + setTemporaryPassword, listApiKeys,
  issueApiKey, revokeApiKey; types `LoginInput`, `PasswordChangeInput`, `ApiKey`, `ApiKeyIssued`.
- 職員 page: 「この職員として操作」 and the acting-staff alerts removed; 状態 column adds tags パスワード未設定 (gold) /
  仮パスワード (blue) / ロック中 (red, until HH:mm); system_admin actions **仮パスワード** (`TemporaryPasswordModal`, not
  yourself) and, for signal_sender staff, **API キー** (`ApiKeysModal`: list with prefix / issued / last used / 取消済み,
  発行 with a label → green alert with the full key + copy button, shown only until the modal closes; 取り消す confirm).
- Texts "ナビの「操作する職員」で…" in OrderDrawer / SignalsPanel / SLA → "このアカウントでは…（利用開始前・停止中）".
- CSS `.login-wrap`, `.login-card`, `.api-key-value`; removed the picker-only `.acting-staff-panel` / `-note` /
  `.is-warning` / `.ant-tag` rules.
- Checked: build; node harness 18/18 against 8001 with a cookie-keeping `fetch` (scratchpad `cookie_fetch.ts`, imported
  first): 401 → signedOut, login failure doesn't sign out, cookie set / cleared, temporary password → 403
  PASSWORD_CHANGE_REQUIRED → change → unblocked, API key issue / list / revoke / non-sender 400; **curl through Vite 5174**:
  401 → login Set-Cookie passes the proxy → 200 → logout 204 → 401; `/login` served. plan_check staff 6 password is
  `check-pass-6` again; API key on staff 10 revoked. **Not checked: the browser.**

### Deployment (branch `feature/deployment`, 2026-11-06; doc rev 89)
User's decisions: **intranet, plain HTTP, no domain, no HTTPS**; **daily `pg_dump` to a local folder** (`./backups`),
the user syncs it to the NAS at OS level; (asked, as I recommended) **01:00 JST, keep 14 days**; **migrations run
automatically at app start**. Earlier: Linux VM + Docker Compose, worker loop. My calls: a separate **`web` (nginx)**
service serves the built frontend and proxies `/api/` → `app:8000/` (same origin, like the Vite proxy) instead of
FastAPI serving static files; compose files live in **`deploy/`** (so the dev `.env` at the root is never read by
Compose; build context `..`); **uvicorn 1 process** (one writer for the rotating `app.log`); worker checks releases at
**second 1 of every minute** (release times are minute-granular ⇒ ≤ 1 min late, same outcome as "sleep until the next
moment, cap 60 s", much simpler).
- `scripts/worker.py`: `order_sync.register()`, loop: plan extension once a day after `WORKER_EXTEND_AT` (00:05 JST;
  also right after start if that day's run hasn't happened), then `release_due_orders`, then
  `stop.wait(seconds_until_next_run)`; errors logged, loop continues; SIGTERM/SIGINT stop after the current pass;
  logs to stdout (releases logged only when something was released). Pure helpers `seconds_until_next_run`,
  `extension_due`, `parse_time` → `tests/test_worker.py` (2, no DB). Ran 75 s against plan_check OK.
- `deploy/app.Dockerfile` (python:3.14-slim + tzdata, TZ=Asia/Tokyo, requirements, copies alembic / main.py / src /
  scripts; `deploy/app-entrypoint.sh`: mkdir logs, `alembic upgrade head`, `exec uvicorn main:app --host 0.0.0.0
  --port 8000 --workers 1 --proxy-headers`), CRLF stripped in the image. `deploy/web.Dockerfile` (node:24-alpine
  `npm ci` + `npm run build` → nginx:1.27-alpine) + `deploy/nginx.conf` (SPA fallback `try_files $uri /index.html`,
  `/assets/` cached 1 y immutable, index no-cache).
- `deploy/docker-compose.yml` (project `ops`): `db` postgres:16 (volume `pgdata`, pg_isready healthcheck), `app`
  (image `ops-app`, `./logs:/app/logs`, `LOG_FILE=/app/logs/app.log`, healthcheck GET `/`), `worker` (same image,
  `python scripts/worker.py`, waits for app healthy = migrations done), `web` (image `ops-web`, port
  `${HTTP_PORT:-80}:80`), `backup` (postgres:16 running `deploy/backup.sh` mounted read-only, `${BACKUP_DIR:-./backups}`);
  shared env `DATABASE_URL` built from `POSTGRES_*`, `ENVIRONMENT=production`, `COOKIE_SECURE=false`, `TZ`; json-file
  logs 10 MB × 5. DB port not published. `deploy/.env.example` (POSTGRES_DB / USER / PASSWORD — letters + digits only,
  HTTP_PORT, BACKUP_DIR / TIME / KEEP_DAYS).
- `deploy/backup.sh`: daily loop (GNU `date -d "today/tomorrow HH:MM"`), `pg_dump --format=custom --compress=6` to
  `<db>_YYYYMMDD_HHMMSS.dump` via a `.partial` name, then `find -mtime +(KEEP-1) -delete` (KEEP 0 = keep all); `once`
  argument for an immediate dump; `BACKUP_DEST` overrides `/backups` (for testing). Tested on the office PC with the local
  PostgreSQL 16 `pg_dump` against plan_check: dump 212 KB, `pg_restore --list` OK, 20-day file removed / 5-day kept, the
  loop fired at the set minute.
- `deploy/README.md` (Japanese runbook): first start, first admin via `docker compose exec app python
  scripts/create_staff.py admin "…" --roles system_admin admin`, update (`git pull` + `docker compose up -d --build`),
  logs, backup now / restore (`pg_restore --clean --if-exists --no-owner` with app + worker stopped), common commands,
  notes (COOKIE_SECURE, `/api/openapi.json`, no Task Scheduler on the server).
- Repo: `.dockerignore` (root), `.gitattributes` `*.sh text eol=lf`, `.gitignore` + `deploy/backups/`, `deploy/logs/`
  (`deploy/.env` already ignored by `.env`).
- **Not verified (no Docker here):** image builds (python:3.14-slim + `psycopg-binary` wheel, `npm ci` in node:24),
  nginx config, compose start-up order / healthchecks, the backup service inside the postgres image. First real run =
  on the VM; check `docker compose ps` / `logs`.

### Todo pool: signal transport "B" — SFTP watcher (parked 2026-11-05, user's choice: start with A)
**A (in use now, nothing built):** the client-file business = LIGHTWEIGHT + MANUAL completion (手で受領), automatic
release, a template at the expected arrival time (its end = the 遅れ deadline); a person checks the client's SFTP in
WinSCP and presses 受領 in the drawer. Downstream jobs wait via 業務の依存関係.
**B (todo, not planned):** a scheduled script (Task Scheduler, every few minutes) that lists the SFTP folders and posts
`POST /ope/signals` for new files → the business switches to AUTOMATIC. Facts from the user (2026-11-05): source is
**SFTP**; today **one user monitors it by hand in WinSCP**; the client's server has **several folders at different
paths**; **some file names carry a timestamp, some don't**; "received" = **the file exists in the right path** (no
marker / size check for now); the final signal of a client-side job = the file appearing in the right path.
Still unknown: server account / access from the scheduler host (read-only?), the date to use when a name has no
timestamp (arrival day JST?), whether files stay after download, how to avoid resends (state file recommended).
Possible first step for both A and B: store the expected SFTP path + file pattern on the business and show it in the
drawer next to 受領 (the person knows where to look; B's watcher reads the same config).

### Open questions (in the doc)
**Still open:** client-limited role details
(name, one or several client codes per user, read-only or also its own client events) · signal transports beyond HTTP
(file arrival, another database) — the matching key is decided (type + client + rule date).
**Decided** (ticked in the doc): early start only with a releaser's approval; releaser + admin release / pin /
force-start (now: approve a dependency override) / resolve conflicts; automatic release default 03:00 JST; rejecting
a step resets only that step (2026-10-30); dependencies same client only (2026-11-04); client event = per business
(2026-11-04); settings = admin, calendar occurrence changes = releaser / admin (2026-11-05, doc rev 70); latest
before due = by scheduled start with a look-back in days (2026-11-05, doc rev 72).

### Planned: client-limited role (decided direction 2026-10-28, not built)
A future role that sees only its own client code(s). Needs a per-user client scope (e.g. `staff_client(staff_user_id,
client_code)`) and every read model / API (calendar, dashboard, orders …) filtering by it — so new endpoints should
take the acting staff into account and keep client filtering in one place. Details are an open question in the doc.

## 2b. Working away from the office (web session or home PC)

The user sometimes continues away from the office PC: in a Claude Code web session (cloud sandbox, Linux) or on a
home PC. Their office `.env` (dev DB) is not available there.
- It clones from GitHub: only **pushed** commits exist there. Push nothing yourself; when done, commit on the branch
  and tell the user to push / pull.
- Not available there: the user's dev DB, their uvicorn on 8000, `plan_check`, Task Scheduler, the Windows paths and
  PowerShell. `.env` / `.env.test` are git-ignored and absent.
- **PostgreSQL runs in Docker (the user's decision, 2026-10-28)** — away from the office (web session or home PC),
  never a native install:
  `docker run -d --name pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres:16`, then create `test_db` and a
  throwaway DB `plan_check` (`docker exec pg createdb -U postgres test_db`, same for `plan_check`), and write
  `.env.test` (`ENVIRONMENT=test`, `DATABASE_URL=postgresql://postgres:postgres@localhost:5432/test_db`) and `.env`
  (`DATABASE_URL=postgresql://postgres:postgres@localhost:5432/plan_check`), then `alembic upgrade head` on
  `plan_check`. Never commit them. If Docker isn't available, say so before writing code and list what can't be
  verified — don't silently switch to another way of running PostgreSQL.
- Python: create a venv and `pip install -r requirements.txt` — commands are `.venv/bin/python` there
  instead of `.venv/Scripts/python.exe` (pyright: `--pythonpath .venv/bin/python`). Frontend: `cd frontend && npm ci`.
- Line endings: the repository stores LF; the Linux checkout is LF everywhere — keep LF (Windows converts on checkout).
- Migrations for the user's dev DB: still only hand them over; the user runs `alembic upgrade head` at home/office.

## 3. Working agreement with the user

- **Baby steps.** The user defines one step at a time with strict limits. Do exactly that step; do not pre-build later
  steps. When a step turns up a real design question, stop and present options with a recommendation; they decide.
- **Commits.** Leave each step uncommitted for review unless asked. When they ask (or approve a finished step with
  "excellent" / "go" / "go ahead"), I commit on the feature branch (conventional-commit style, `Co-Authored-By` line).
  Never push. The user sometimes commits and pushes a step themselves (short messages like "fix") — check `git log`
  before committing, and never amend or rewrite their pushed commits.
  Before starting a step, check `git status`; if the previous step is uncommitted, say so.
- **Don't touch the user's dev DB or their running uvicorn (port 8000).** Read-only GETs against 8000 are fine (useful for
  diagnosing their test data; `app.log` in the repo root logs SQL for both servers). For end-to-end checks use the
  throwaway DB `plan_check` (already exists and migrated; seeded with client `MOCK`, biz 1, calendar `JP_BANK` id 1,
  the mock sheet), uvicorn on 8001 with `DATABASE_URL` pointing at `plan_check`, and Vite on 5174:
  `VITE_PROXY_TARGET=http://127.0.0.1:8001 exec node node_modules/vite/bin/vite.js --port 5174 --strictPort` (from `frontend/`).
  Start Vite with `node` directly, not `npm run dev`: TaskStop only kills the npm wrapper and leaves Vite running.
  Wait until `http://localhost:5174/api/plans/calendars` returns 200 before running a harness.
  Vite binds to `localhost` (IPv6), so harnesses use `http://localhost:5174/api`. Never run bare `npx vite` from the repo root.
- **Verify before claiming.** Build + type check every change; backend changes need pytest + pyright (+ `alembic check`
  for migrations). For API-facing frontend work, bundle the real domain/feature modules with esbuild
  (`--define:import.meta.env='{"VITE_API_BASE_URL":"http://localhost:5174/api","VITE_TIMEZONE":"Asia/Tokyo"}'`) and run
  them in node against the throwaway backend. Say plainly what was *not* checked (I can't click through the browser; the
  user does that).
- **Design work** (cross-domain, for the team) goes into a Claude Docs document, not chat. Record each step's
  decisions in the doc (a short "Decided …, built in X.Y" paragraph or a data-model row) and in §2 here.
- **"go" from the user** (also typed "GO" or "ご" with the Japanese IME) after a finished step = commit it; after a
  commit = start the next step (questions first). "commit and merge" = commit, then merge the feature branch into
  `main` locally with `--no-ff` (check `main` hasn't diverged first); they push.
- **Logging (2026-11-05):** `app.log` rotates by size (`RotatingFileHandler` in `main.py`: 10 MB × 5 backups; env vars `LOG_FILE` / `LOG_MAX_MB` / `LOG_BACKUPS` — real env vars, `.env` is not exported). **Start my uvicorn on 8001 with `LOG_FILE=app-8001.log`** (Windows can't rename a file another process holds open). The user's old app.log was 1.3 GB (SQL echo); SQL logging is **off by default** since 2026-11-05 (`settings.sql_echo`, `SQL_ECHO=1` in `.env` or the env to turn it on); the scripts still force it off for themselves.
- **Shell / editing lessons (2026-11-04):** write edit scripts to the scratchpad with the Write tool and run them
  with `python <file> < /dev/null` — never `python - <<'EOF' < /dev/null` (the redirect replaces the heredoc →
  interactive REPL that hangs), never `sed … $f` with a possibly empty `$f` (reads stdin, hangs). Build the whole new
  text before `open(path, "w")` (a failing call after opening empties the file — happened to `styles.css`, restored
  from git). Anchors in edit scripts must be unique (`# --- System Audit Trail ---` repeats in biz models). The shell
  cwd drifts between calls: use absolute paths (`/c/p/postgres-migration-poc/...`). Backgrounded uvicorn:
  `--app-dir /c/p/postgres-migration-poc --port 8001`, stop it with TaskStop when done. Harnesses can call uvicorn
  8001 directly (`VITE_API_BASE_URL=http://127.0.0.1:8001`; the Vite proxy only strips `/api`).
- Code comments in the repo are Japanese; UI text is Japanese; replies to the user in English.
- Line endings: the ope / dashboard frontend files and `styles.css` are LF in the working tree (checked 2026-11-04;
  older notes said CRLF); backend Python files, migrations and MEMORY.md are LF. Match the file you edit. Japanese in shell arguments gets mangled (cp932): pass JSON via files and run Python with
  `PYTHONUTF8=1`; long inline Python heredocs can break bash parsing → write the script to the scratchpad and run it.
  `.env`/`.env.*` are git-ignored.

## 4. Backend as built (FastAPI + SQLAlchemy 2 + PostgreSQL)

Layering per domain: `models.py` / `schemas.py` / `services.py` / `router.py`, repositories in
`src/infrastructure/repositories/` (`CRUDBase`, `SoftCRUDBase`). Errors: `BusinessException` subclasses
(`BadRequestError` 400, `NotFoundError` 404, `DuplicatedRecordError` 409) → `{status_code, error_code, message}`.
Global soft-delete filter (`do_orm_execute` + `with_loader_criteria(SoftDeleteMixin)`) hides deleted rows;
use `.execution_options(include_deleted=True)` to bypass. Domains in `src/`: `domain_biz`, `domain_client`, `domain_plan`.

### Plan domain (`src/domain_plan/`)
- **Templates** (`plan_template`, soft-deletable) — 3 types:
  `RRULE` (anchor_date + rrule), `EXPLICIT_DATES` (`plan_explicit_date`),
  `REFERENCE_SHEET_BASED` (sheet + marker + `offset_days`/`offset_day_unit` calendar|business + `offset_minutes`).
  Common: `start_time`, `duration_minutes`, `timezone`, `holiday_policy`, `business_calendar_id`, `ui_metadata` (JSONB,
  extra keys allowed; replaced as a whole on PATCH).
- **Template update (PATCH)** compares values: unchanged fields don't bump `revision`; fields of another template type → 400.
  Name / `ui_metadata` changes never bump revision. Delete = soft delete (future instances voided `TEMPLATE_DELETED`,
  past kept); template restore exists in the API but the user decided not to build it.
- **Engine** (`engine.py`, pure functions): local wall-clock + IANA tz → UTC (DST-safe). Holiday policies:
  `as_is`, `skip`, `following`, `preceding`, `modified_following`, `modified_preceding`. Rolled occurrences keep their
  original rule date as slot identity (`occurrence_date`); collisions on one day collapse to one.
- **Instances are immutable** (`plan_instance`, DB trigger `plan_reject_mutation` blocks UPDATE/DELETE on
  `plan_instance`, `plan_instance_void`, `plan_slot_release`). Changes are append-only:
  - `origin`: `GENERATED` / `OVERRIDE` (manual reschedule, `overrides_instance_id` chain) / `ONE_OFF`.
  - Void reasons: `TEMPLATE_REVISED`, `TEMPLATE_DELETED`, `SOURCE_DATE_CHANGED`, `MANUAL`, `REVERTED`, `CALENDAR_CHANGED`.
  - Regeneration = **reconcile** (desired vs live generated instances) over `materialized_until` (see §2 visibility).
    Manually changed/cancelled slots are never regenerated.
  - Generation-affecting template edits bump `revision` and reconcile only the future; the past is never touched.
- **Manual operations on instances:** override, cancel, revert (back to rule), one-off, restore cancelled
  (`POST /plans/instances/{id}/restore`, used by the 取消済みの予定 drawer; not the same as template restore).
- **Occurrence cache** (`plan_occurrence_cache`): denormalized across all clients, GiST `tstzrange` index, effective
  `ui_metadata` — the natural source for the daily dashboard.
- **Business calendars:** `business_calendar` (weekend days) + `business_calendar_holiday`; changes cascade to templates
  and generated markers. **Past holidays are read-only (backend-enforced):** add / rename / delete before today → 400;
  a request containing any past date is rejected as a whole.
- **"Today"** for sheet dates and holidays is JST: `LOCAL_TIMEZONE`, `_local_today()`; `_check_not_past(dates, action)`
  raises the 400.

### Reference sheets (client annual plans) — audit rules, decided with the user
`reference_sheet` → `reference_sheet_marker` → `reference_sheet_event`. Real workflow: one baseline marker per client
(e.g. 振込日 = 27th, next business day) with several jobs offset from it (3 business days before, …). Every date change
cascades to all templates referencing the marker (`_propagate_sheet_change`).
- **Markers:** imported (`POST /plans/sheets/import`, JSON format of `mock_data/desensitized_mock_data.json`; import cannot
  create rule markers) or **rule-generated** (`POST /plans/sheets/{id}/markers` with `rule`; `PATCH …/markers/{marker}`
  changes the rule, `rule: null` stops generating).
- **Stopping a rule** = freeze by default: dates and dependent jobs stay, but holidays no longer move them. With
  `cancel_future_dates: true` (only allowed with `rule: null`; the routine has ended) every date from today on is
  cancelled in one transaction, by the same rules as a single delete (`_cancel_sheet_event`); past dates untouched.
- **Event provenance** (never erased, including after stopping a rule): `rule_date` (rule slot), `original_date`
  (imported/rule date before a person moved or cancelled it), `is_manual` (a person changed it), `is_cancelled`
  (取消 record). UI labels: ルール / 人が変更 (元: original) / 人が追加 / 取消 / 取り込み.
- **People always win:** manual edits are kept on rule change, calendar change, re-import and `replace_events`.
  Option 1 (user's decision): a manual future date can coexist with a new rule date in the same month; the system
  does not auto-delete it, the UI warns (edit form, after save, orange 「今後: …」 tag) and the user cleans up.
- **Deleting:** rule/imported dates become 取消 records; hand-added dates (no rule/original date) are hard-deleted
  (a record would block that day for future rule dates via the unique `(marker_id, event_date)` constraint).
- **Past is read-only (backend-enforced):** add / move / delete / revert of dates before today → 400. Rule and holiday
  changes don't rewrite past dates; only a new marker's first generation fills the past. Import is still allowed to add
  past dates (initial loads need it), and `replace_events` can still delete past imported dates that nobody edited.
- **`revertable`** on each event (computed, not stored; `_annotate_revertable`): true only if the current rule produces
  that slot on a free date ≥ today. Same conditions as `POST /plans/sheets/events/{id}/revert`.

### Coordination layer (`src/coordination/`) as built
Not a domain: a flat package (`schemas.py` / `services.py` / `router.py`, prefix `/ops`) that reads plan / biz / client.
It calls only public plan functions (`plan_services.materialize_all_templates`), never plan's private helpers.
- **`GET /ops/daily?date=&timezone=Asia/Tokyo`** (`date` optional → today in `timezone`; alias of `target_date`):
  live occurrences **starting** that day (same day split as the calendar), grouped client → business (both by code);
  sheet dates (`DailyMilestone`, with provenance) under the client; `calendars[]` = every business calendar with
  `is_business_day` / `holiday_name`. **Past dates only:** `voided[]` per business (reason, note, voided_at; includes
  deleted templates via `include_deleted`, excludes deleted businesses) and cancelled sheet dates.
  Clients with only sheet dates appear with `businesses: []`. Reads through generation up to 2 years.
- Repos added for it: `plan_cache_repo.query_starting_in`, `plan_instance_repo.get_voided_starting_in`,
  `reference_sheet_repo.get_events_on`, `plan_template_repo.get_all`, `client_repo.get_by_codes`.
- Its own `_now()` (tests monkeypatch `ops_services._now` to view a day as past).

### Plan generation job (Phase 2)
`plan_services.extend_all_templates(db) -> TemplateExtensionResult {templates_checked, templates_extended,
without_upcoming}`; script `scripts/extend_plans.py` (sets `engine.echo = False` for itself, one log line, exit 1 on
failure). `PlanTemplateResponse.next_occurrence_at` (computed per response by `_with_next_occurrence` from the cache via
`plan_cache_repo.next_starts`; null on delete responses).

### Staff domain (`src/domain_staff/`) as built (Phase 3)
- Tables `staff_user` (login_id unique, name, email, `status`), `role` (id, code unique, name, description; seeded by
  the migration and, for `create_all` in tests, by an `after_create` DDL in models.py), `staff_role` (composite PK,
  `granted_at`, `granted_by_id`). Staff are never deleted (future order / step events reference them); suspend instead.
- **Roles (user's list):** operator, checker, releaser, admin (business), viewer, auditor, system_admin (account admin,
  not business work). Global, a user can hold several. `RoleCode` enum in models.py.
- **Status, not roles (my call, user didn't object):** `pending → active ⇄ suspended`; no way back to pending. Only
  `active` staff can act; suspended keep their roles.
- **Guards (user asked for decorators):** `@require_roles(["checker", "releaser"])` / `@require_active()` in
  `domain_staff/auth.py`, placed **under** `@router.<method>`. They add a hidden keyword-only param
  (`_require_roles_current_staff = Depends(get_current_staff)`) to the signature and pop it in the wrapper; sync and
  async; role typos fail at import. Errors: 401 `UNAUTHORIZED` (no / unknown header), 403 `STAFF_NOT_ACTIVE`,
  403 `FORBIDDEN` (missing role). `ForbiddenError` in core/exceptions; `AUTH_ERRORS` in core/schemas/error.py.
- `get_current_staff` reads the trusted `X-Staff-Id` header — the one place to replace when real login comes.
  Endpoints that need the actor also declare `current_staff: StaffUser = Depends(get_current_staff)` (cached per request).
- `/staff`: `GET /me` (any status) · `GET /roles` (active) · `GET /`, `GET /{id}` (system_admin, admin, auditor) ·
  `POST /`, `PATCH /{id}`, `PUT /{id}/roles`, `PUT /{id}/status` (system_admin). Lockout guards: can't change own
  status, can't remove own system_admin. Plan / ops endpoints are **not** guarded yet.
- `scripts/create_staff.py <login_id> <name> --roles system_admin [--email]` creates an **active** user (bootstrap).

### Biz domain (`src/domain_biz/`) as built
`biz_master` (client_code, business_seq → business_code, name, …) → `sop_version` (version_number, version_tag,
status, `effective_at`, `expired_at`; clone / approve / cancel endpoints) → `sop_step_template` (step_num, title,
content, `condition` JSONB, `is_blocking` — 5.1). Also `biz_dependency` (6.1) and the client-event settings
`execution_type` / `completion_mode` / `signal_type` (7.1); execution itself lives in ope.
**Release settings (4.1):** `release_mode` (`ReleaseMode`: MANUAL_APPROVAL default | AUTOMATIC; stored as member
names), `release_time` (Time, default 03:00 JST), `release_days_before` (0–30, default 0, CHECK
`chk_biz_release_days_before`). New businesses get the defaults (the shared `CRUDBase.create` runs
`jsonable_encoder`, which turns enums into value strings the Enum column rejects — so create doesn't take them);
change them with `PATCH /biz/{id}` (`model_dump`, explicit nulls refused for these three only).
Migration gotchas seen: `op.add_column` with an Enum does not create the PG type (create it first, drop it on
downgrade); autogenerate never emits CHECK constraints.

### Key endpoints used by the frontend
| Purpose | Endpoint |
|---|---|
| Client month calendar | `GET /plans/clients/{code}/calendar?month=&timezone=&holiday_calendar=` |
| Cancelled list / restore | `GET /plans/clients/{code}/cancelled?start=&end=`, `POST /plans/instances/{id}/restore` |
| Override / cancel / revert | `POST /plans/instances/{id}/override` · `/cancel` · `/revert` |
| One-off | `POST /plans/templates/{id}/instances` |
| Templates | `GET /plans/templates?biz_id=`, `POST /plans/templates`, `PATCH` / `DELETE /plans/templates/{id}`, `POST` / `DELETE …/dates` |
| Sheets / markers | `GET /plans/sheets?client_code=`, `POST /plans/sheets/{id}/markers`, `PATCH /plans/sheets/{id}/markers/{marker}` |
| Sheet dates | `POST …/markers/{marker}/events`, `PATCH` / `DELETE /plans/sheets/events/{id}`, `POST …/events/{id}/revert` |
| Holidays | `GET /plans/calendars/{id}/holidays` (all years; the page filters by year), `POST …/holidays` (re-posting a date only renames it, no regeneration), `DELETE …/holidays/{date}`; past dates → 400 |
| Lookups | `GET /clients/`, `GET /biz/` (limit 1000 requested), `GET /plans/calendars` |
| Business settings | `PATCH /biz/{id}` (release + client-event settings; unguarded like the rest of biz) |
| Dashboard | `GET /ops/daily?date=&timezone=` (rows carry order `{id, status, conflict, steps_total, steps_approved, blocked, late}`) |
| Orders | `GET /ope/orders/{id}` (detail: steps, dependencies, dependents, events, late, execution_type, completion_mode); `POST /ope/orders/{id}/release · approve-early-start · approve-dependency-override · start · hold · resume · finish · cancel · resolve-conflict · pin · unpin` |
| Steps | `POST /ope/steps/{id}/submit` (operator) · `/approve` · `/reject` (checker, four-eyes) |
| Dependencies | `GET /biz/clients/{code}/dependencies`, `GET /biz/{id}/dependencies`, `POST /biz/{id}/dependencies` + `DELETE /biz/dependencies/{id}` (admin) |
| Signals | `POST /ope/signals` (signal_sender), `GET /ope/signals?scope=open\|all&client_code=&since=`, `POST /ope/signals/{id}/handle` (operator / releaser / admin) |

Unused Plan endpoints, kept on purpose: sheet import UI + `POST /plans/sheets` (sheet creation) — still open, waiting
on the Excel-vs-JSON question; template audit history `GET /plans/templates/{id}/instances`; calendar create / weekend
change; flat occurrence lists `GET /plans/occurrences`, `GET /plans/clients/{code}/occurrences`; cache rebuild
(backend-only); template restore (decided not needed).

Optional CORS via `CORS_ORIGINS` in `.env` (dev uses the Vite proxy instead).

## 5. Frontend as built (`frontend/`)

Vite 5.4 + React 18 + TypeScript + **Ant Design 5.22** (ja_JP locale, theme tokens match `styles.css`) + dayjs +
react-router-dom 6.28. Exact-pinned versions. Plain CSS with color variables (light/dark), no Tailwind.

- **OpenAPI-generated types:** `python scripts/export_openapi.py` → `frontend/openapi.json`;
  `npm run gen:api` → `src/shared/api/schema.gen.ts` (never edit by hand; regenerate after backend schema changes).
  Typed client: `openapi-fetch` (`src/shared/api/http.ts`, `unwrap()` → `ApiError{status, code, message}`).
- **Layering (one direction): `features → domain → shared`.** UI never calls HTTP directly.
  - `domain/{plan,biz,client,ops,staff}/{types,api,hooks,lib}` — types are aliases of generated schemas only.
    `domain/plan/lib/category.ts`: template category stored in `ui_metadata.category` (missing → 定例; display-only —
    "who acts" for client events must be a real biz field, not this).
    `domain/plan/lib/jpHolidays.ts`: Japanese national holidays calculated from the current law (equinox formula,
    happy Mondays, 振替休日, 国民の休日), 2022–2099 only; matches the official lists for 2024–2027.
  - `shared/` — http client, `useApiQuery`, `datetime.ts`, `useNow`, `ui/color.ts`, `config.ts` (`TIMEZONE`).
  - `features/calendar`, `features/schedule-actions`, `features/plan-settings`.
    Pure logic lives in `templateForm.ts` / `markerForm.ts` / `holidayForm.ts` (testable in node); modals are UI only.
- **Routes / nav:** `/` calendar (`?client=&month=&holidays=`) · `/daily?date=` 日次ダッシュボード (order drawer,
  signals panel) · `/settings/templates?biz=` (+ 業務の設定 panel) · `/settings/sheets?client=` ·
  `/settings/holidays?calendar=<id>&year=` · `/settings/dependencies?client=` 業務の依存関係 · `/settings/staff` 職員.
  Domain modules for Phases 4–7: `domain/ope/{types,api (orderApi, signalApi),hooks,lib (orderActions, stepActions,
  signals)}`, `domain/biz/{api (bizApi, dependencyApi),lib (dependencies, settings)}`.
- **日次ダッシュボード** (`features/daily-dashboard`, data via `domain/ops/{types,api,hooks}`): prev / next day, date
  picker, 今日; calendar tags (営業日 / 休日（name） / 休業日（週末）); one card per client (code links to its calendar
  month), sheet-date tags with provenance labels, occurrences per business (time, chipStyle swatch + Icon, 人が変更 /
  臨時 tags, 元の日付 when the slot date differs); past days add struck-through voided rows with the reason
  (`VOID_REASON_LABEL`) and note. Pure logic in `dailyDashboard.ts`.
- **Login (LG.3, replaced the acting-staff picker):** `/login` page; session in the HttpOnly `ops_session` cookie;
  `shared/api/session.ts` + `useSession`; http.ts marks signed out on 401; `AppLayout` redirects to `/login` and forces
  a password change for temporary passwords; nav `UserMenu` (パスワードを変更, ログアウト). Detail in §2 "Login".
- **職員** (`/settings/staff`, `features/staff-settings`): list, 職員を登録, 編集 (name, email, role checkboxes; own
  system_admin locked), 有効化 / 利用停止 / 再開 (confirm; own row disabled), 仮パスワード / API キー (system_admin, LG.3). UI permissions in
  `domain/staff/lib/permissions.ts` mirror the backend (display only).
- **Template settings page:** 「次の予定」 column (template timezone) and a warning tag + banner for templates with no
  upcoming occurrence. The layout remembers each page's last query string, so switching pages keeps
  selections. The calendar's `useUrlState` goes through react-router (`useSearchParams`), not `history.replaceState`.
- **Calendar:** category chips (定例 hidden by default, stored in localStorage) + per-template legend toggles; sticky nav
  (`--nav-h: 44px`) and sticky weekday row (`.month` uses `overflow: clip` so sticky works).
- Dev: `npm run dev` (proxy `/api` → `http://127.0.0.1:8000`; IPv4 on purpose). Production needs SPA fallback to `index.html`.
- Gotchas already fixed — don't regress: ColorPicker `onChange` 2nd arg is `rgb(...)`, use `hexFromColorPicker`;
  dayjs custom formats need `customParseFormat`; antd Modal + `forceRender` without `destroyOnClose` → reset the form in
  a `useEffect` on `open` and keep the target in state while closing; `ui_metadata` PATCH replaces the whole object, so
  forms carry over unknown keys (`text_color` …). openapi-typescript marks every field with a default as required, so
  request bodies send those fields explicitly (e.g. `cancel_future_dates: false`, `offset_days`).

## 6. Known data quirks (user's dev DB)
- Client `MOCK`, 15 businesses; only some have templates. Template names vs business names look shifted by one.
- Sheets: `Annual_Schedule` (id 2, imported) and `MOCK_Schedule` (id 1). Marker `引落日` (id 10) was a rule marker; its
  history was wiped by the old 生成をやめる before the audit-trail fix (unrecoverable, accepted by the user).
- Calendar `JP_BANK` id 1 (holidays 2026-11-03, 2026-11-23 …).
- Instance 910 (10/20) was moved into the past and cancelled; it shows in the cancelled list as not restorable.
- Dates moved before migration `5c1f7d2a9e04` have no `original_date`; dates added via the UI on imported markers before
  it look like 取り込み.
